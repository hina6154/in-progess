'use client'

import { motion } from 'framer-motion'
import { useState } from 'react'
import { FiUser, FiMail, FiPhone, FiChevronDown, FiChevronUp, FiFilter } from 'react-icons/fi'

export default function LeadTable({ leads }: { leads: any[] }) {
  const [sortConfig, setSortConfig] = useState({ key: 'name', direction: 'ascending' })
  const [expandedRow, setExpandedRow] = useState<number | null>(null)

  const sortedLeads = [...leads].sort((a, b) => {
    if (a[sortConfig.key] < b[sortConfig.key]) {
      return sortConfig.direction === 'ascending' ? -1 : 1
    }
    if (a[sortConfig.key] > b[sortConfig.key]) {
      return sortConfig.direction === 'ascending' ? 1 : -1
    }
    return 0
  })

  const requestSort = (key: string) => {
    let direction = 'ascending'
    if (sortConfig.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending'
    }
    setSortConfig({ key, direction })
  }

  const toggleRow = (id: number) => {
    setExpandedRow(expandedRow === id ? null : id)
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead className="bg-cyber-darker border-b border-gray-800">
          <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
              <button
                onClick={() => requestSort('name')}
                className="flex items-center hover:text-cyber-primary transition-colors"
              >
                <FiUser className="mr-2" />
                Name
                {sortConfig.key === 'name' && (
                  sortConfig.direction === 'ascending' ? (
                    <FiChevronUp className="ml-1" />
                  ) : (
                    <FiChevronDown className="ml-1" />
                  )
                )}
              </button>
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
              <button
                onClick={() => requestSort('email')}
                className="flex items-center hover:text-cyber-primary transition-colors"
              >
                <FiMail className="mr-2" />
                Email
                {sortConfig.key === 'email' && (
                  sortConfig.direction === 'ascending' ? (
                    <FiChevronUp className="ml-1" />
                  ) : (
                    <FiChevronDown className="ml-1" />
                  )
                )}
              </button>
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
              <button
                onClick={() => requestSort('phone')}
                className="flex items-center hover:text-cyber-primary transition-colors"
              >
                <FiPhone className="mr-2" />
                Phone
                {sortConfig.key === 'phone' && (
                  sortConfig.direction === 'ascending' ? (
                    <FiChevronUp className="ml-1" />
                  ) : (
                    <FiChevronDown className="ml-1" />
                  )
                )}
              </button>
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
              <div className="flex items-center">
                <FiFilter className="mr-2" />
                Status
              </div>
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
              Source
            </th>
            <th className="px-6 py-3 text-right text-xs font-medium text-gray-400 uppercase tracking-wider">
              Actions
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-800">
          {sortedLeads.map((lead) => (
            <motion.tr
              key={lead.id}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3 }}
              className={`hover:bg-cyber-darker/50 ${expandedRow === lead.id ? 'bg-cyber-darker/30' : ''}`}
            >
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex items-center">
                  <div className="flex-shrink-0 h-10 w-10 rounded-full bg-cyber-primary/10 flex items-center justify-center text-cyber-primary">
                    <FiUser />
                  </div>
                  <div className="ml-4">
                    <div className="text-sm font-medium">{lead.name}</div>
                  </div>
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm">{lead.email}</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm">{lead.phone}</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                  lead.status === 'New' ? 'bg-blue-500/10 text-blue-500' :
                  lead.status === 'Contacted' ? 'bg-purple-500/10 text-purple-500' :
                  'bg-green-500/10 text-green-500'
                }`}>
                  {lead.status}
                </span>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-400">
                {lead.source}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                <button
                  onClick={() => toggleRow(lead.id)}
                  className="text-cyber-primary hover:text-cyber-accent mr-3"
                >
                  {expandedRow === lead.id ? 'Hide' : 'View'}
                </button>
              </td>
            </motion.tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}