'use client'

import { motion } from 'framer-motion'
import { useState } from 'react'
import { FiPlus, FiSettings, FiActivity } from 'react-icons/fi'

export default function AssistantCard({ template }: { template: any }) {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <motion.div
      whileHover={{ y: -5 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      className="relative overflow-hidden rounded-xl border border-gray-800 p-6"
      style={{
        background: `
          linear-gradient(
            to bottom right,
            rgba(10, 10, 18, 0.8),
            rgba(6, 6, 11, 0.9)
          )
        `,
      }}
    >
      {/* Grid Background */}
      <div className="absolute inset-0 opacity-20" style={{
        backgroundImage: `
          linear-gradient(to right, rgba(0, 240, 255, 0.1) 1px, transparent 1px),
          linear-gradient(to bottom, rgba(0, 240, 255, 0.1) 1px, transparent 1px)
        `,
        backgroundSize: '40px 40px'
      }} />

      {/* Animated Hover Effect */}
      <motion.div
        animate={{
          opacity: isHovered ? 0.1 : 0.05,
          scale: isHovered ? 1.1 : 1,
        }}
        transition={{ duration: 0.3 }}
        className="absolute inset-0 bg-gradient-to-br from-cyan-400/30 to-blue-400/30 rounded-full blur-xl"
      />

      {/* Glowing Border Effect */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: isHovered ? 1 : 0 }}
        className="absolute inset-0 border border-cyan-400/30 rounded-xl"
        style={{
          boxShadow: '0 0 25px rgba(0, 240, 255, 0.1)'
        }}
      />

      <div className="relative z-10">
        <div className="flex items-center justify-between mb-4">
          <div className="w-12 h-12 bg-cyan-400/10 rounded-lg flex items-center justify-center border border-cyan-400/20">
            <FiActivity className="text-cyan-400 text-xl" />
          </div>
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            className="p-2 rounded-lg bg-gray-800/50 border border-gray-700 hover:border-cyan-400/50 transition-all"
          >
            <FiPlus className="text-cyan-400" />
          </motion.button>
        </div>

        <h3 className="text-xl font-semibold mb-1 text-cyan-400">{template.name}</h3>
        <p className="text-gray-400 text-sm mb-4">{template.description}</p>

        <motion.button
          whileHover={{ 
            backgroundColor: 'rgba(0, 240, 255, 0.1)',
            borderColor: 'rgba(0, 240, 255, 0.5)'
          }}
          className="w-full py-2 px-4 rounded-lg border border-gray-700 flex items-center justify-center text-sm font-medium text-cyan-400 hover:text-cyan-300 transition-all"
        >
          <FiSettings className="mr-2" />
          Configure Assistant
        </motion.button>
      </div>
    </motion.div>
  )
}