'use client'

import { motion } from 'framer-motion'

// LiningBackground component
const LiningBackground = () => {
  return (
    <div className="fixed inset-0 -z-50 bg-gradient-to-br from-gray-900 via-gray-950 to-gray-900 overflow-hidden">
      {/* Base Grid Layer */}
      <motion.div
        className="absolute inset-0 bg-[length:40px_40px] opacity-15"
        animate={{
          backgroundPosition: ['0% 0%', '100% 100%']
        }}
        transition={{
          duration: 40,
          repeat: Infinity,
          ease: 'linear'
        }}
        style={{
          backgroundImage: `
            linear-gradient(rgba(0, 240, 255, 0.1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0, 240, 255, 0.1) 1px, transparent 1px)
          `
        }}
      />

      {/* Animated Scanning Lines */}
      <motion.div
        className="absolute inset-0 opacity-20"
        animate={{
          backgroundPosition: ['0% 0%', '0% 100%']
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: 'linear'
        }}
        style={{
          backgroundImage: `
            repeating-linear-gradient(
              0deg,
              rgba(0, 240, 255, 0.1) 0px,
              rgba(0, 240, 255, 0.1) 1px,
              transparent 1px,
              transparent 8px
            )
          `
        }}
      />

      {/* Diagonal Grid Pattern */}
      <motion.div
        className="absolute inset-0 bg-[length:80px_80px] opacity-10"
        animate={{
          backgroundPosition: ['0% 0%', '100% 100%']
        }}
        transition={{
          duration: 60,
          repeat: Infinity,
          ease: 'linear'
        }}
        style={{
          backgroundImage: `
            repeating-linear-gradient(
              45deg,
              rgba(0, 240, 255, 0.05) 0 1px,
              transparent 1px 40px
            ),
            repeating-linear-gradient(
              -45deg,
              rgba(0, 240, 255, 0.05) 0 1px,
              transparent 1px 40px
            )
          `
        }}
      />

      {/* Pulsing Glow Effect */}
      <motion.div
        className="absolute inset-0 bg-gradient-radial from-cyan-400/10 to-transparent"
        animate={{
          opacity: [0.05, 0.15, 0.05]
        }}
        transition={{
          duration: 4,
          repeat: Infinity
        }}
      />

      {/* Moving Scan Line */}
      <motion.div
        className="absolute inset-x-0 h-px bg-gradient-to-r from-transparent via-cyan-400/50 to-transparent"
        initial={{ top: '0%' }}
        animate={{ top: '100%' }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: 'linear'
        }}
      />
    </div>
  )
}

// AnimatedForm component
const AnimatedForm = () => (
  <div className="relative min-h-screen">
    <LiningBackground />
    
    <motion.form
      variants={formVariants}
      initial="hidden"
      animate="visible"
      className="max-w-md mx-auto p-8 bg-gray-800/50 backdrop-blur-lg rounded-xl border border-cyan-500/20"
    >
      <motion.div variants={itemVariants} className="mb-6">
        <label className="block text-cyan-400 mb-2">Username</label>
        <input
          type="text"
          className="w-full bg-gray-900/50 rounded-lg px-4 py-2 border border-cyan-500/20 focus:outline-none focus:ring-2 focus:ring-cyan-400"
        />
      </motion.div>

      <motion.div variants={itemVariants} className="mb-6">
        <label className="block text-cyan-400 mb-2">Password</label>
        <input
          type="password"
          className="w-full bg-gray-900/50 rounded-lg px-4 py-2 border border-cyan-500/20 focus:outline-none focus:ring-2 focus:ring-cyan-400"
        />
      </motion.div>

      <motion.div variants={itemVariants}>
        <button className="w-full bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400 py-2 px-4 rounded-lg transition-all">
          Sign In
        </button>
      </motion.div>
    </motion.form>
  </div>
)

// Animation variants for the form
const formVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      staggerChildren: 0.2,
      delayChildren: 0.3
    }
  }
}

// Animation variants for individual items
const itemVariants = {
  hidden: { opacity: 0, y: 10 },
  visible: { opacity: 1, y: 0 }
}

export default AnimatedForm


