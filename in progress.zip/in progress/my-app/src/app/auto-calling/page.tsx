'use client'

import { motion } from 'framer-motion'
import { 
  Box, 
  Typography, 
  Chip, 
  Paper, 
  List, 
  ListItemButton, 
  ListItemIcon, 
  ListItemText,
  Button,
  TextField,
  Divider,
  Avatar,
  IconButton
} from '@mui/material'
import Link from 'next/link'
import { FiHome, FiPhone, FiUsers, FiDollarSign, FiSettings, FiUpload, FiDownload } from 'react-icons/fi'
import { FaRobot } from 'react-icons/fa'
import { IoMdAdd } from 'react-icons/io'
import { useState } from 'react'

interface Call {
  id: number
  phoneNumber: string
  status: 'scheduled' | 'in progress' | 'completed' | 'failed'
  time: string
  duration?: string
  followUp?: string
}

const CallCard = ({ call }: { call: Call }) => (
  <Paper sx={{
    p: 3,
    mb: 2,
    border: '1px solid rgba(34, 211, 153, 0.2)',
    bgcolor: 'rgba(17, 24, 39, 0.3)',
    backdropFilter: 'blur(8px)',
    borderRadius: 2,
    '&:hover': { bgcolor: 'rgba(17, 24, 39, 0.5)' }
  }}>
    <Box display="flex" justifyContent="space-between" alignItems="flex-start">
      <Box>
        <Typography variant="body1" fontWeight={500} color="#e5e7eb">
          {call.phoneNumber}
        </Typography>
        <Box mt={1} display="flex" alignItems="center" gap={2}>
          <Typography variant="body2" color="#22d3ee" sx={{ opacity: 0.7 }}>
            Time
          </Typography>
          <Typography variant="body2" color="#e5e7eb">
            {call.time}
          </Typography>
        </Box>
        {call.duration && (
          <Box mt={1} display="flex" alignItems="center" gap={2}>
            <Typography variant="body2" color="#22d3ee" sx={{ opacity: 0.7 }}>
              Duration
            </Typography>
            <Typography variant="body2" color="#e5e7eb">
              {call.duration}
            </Typography>
          </Box>
        )}
        {call.followUp && (
          <Box mt={1} display="flex" alignItems="center" gap={2}>
            <Typography variant="body2" color="#22d3ee" sx={{ opacity: 0.7 }}>
              Follow-up
            </Typography>
            <Typography variant="body2" color="#e5e7eb">
              {call.followUp}
            </Typography>
          </Box>
        )}
      </Box>
      <Chip
        label={call.status}
        size="small"
        sx={{
          bgcolor: 
            call.status === 'completed' ? 'rgba(16, 185, 129, 0.2)' :
            call.status === 'scheduled' ? 'rgba(34, 211, 153, 0.2)' :
            call.status === 'in progress' ? 'rgba(59, 130, 246, 0.2)' :
            'rgba(244, 63, 94, 0.2)',
          color: 
            call.status === 'completed' ? '#34d399' :
            call.status === 'scheduled' ? '#22d3ee' :
            call.status === 'in progress' ? '#3b82f6' :
            '#f43f5e'
        }}
      />
    </Box>
  </Paper>
)

const StatCard = ({ title, value }: { title: string; value: string }) => (
  <Paper sx={{
    p: 2,
    flex: 1,
    border: '1px solid rgba(34, 211, 153, 0.2)',
    bgcolor: 'rgba(17, 24, 39, 0.3)',
    backdropFilter: 'blur(8px)',
    borderRadius: 2,
    textAlign: 'center'
  }}>
    <Typography variant="body2" color="#22d3ee" sx={{ opacity: 0.8 }}>
      {title}
    </Typography>
    <Typography variant="h5" color="#e5e7eb" sx={{ mt: 1 }}>
      {value}
    </Typography>
  </Paper>
)

const navItems = [
  { name: 'Dashboard', icon: FiHome, path: '/' },
  { name: 'Assistants', icon: FaRobot, path: '/assistant' },
  { name: 'Phone-Number', icon: FiSettings, path: '/phone-number' },
  { name: 'Auto Calling', icon: FiPhone, path: '/auto-calling' },
  { name: 'Leads', icon: FiUsers, path: '/leads' },
  { name: 'Billing', icon: FiDollarSign, path: '/billing' },
  { name: 'Settings', icon: FiSettings, path: '/settings' },
 
]

const calls: Call[] = [
  { 
    id: 1, 
    phoneNumber: '+1 (555) 123-4567', 
    status: 'completed', 
    time: 'Today, 9:30 AM',
    duration: '3m 42s'
  },
  { 
    id: 2, 
    phoneNumber: '+1 (555) 987-6543', 
    status: 'scheduled', 
    time: 'Tomorrow, 2:00 PM',
    followUp: 'Scheduled for 3 days after'
  },
  { 
    id: 3, 
    phoneNumber: '+1 (555) 456-7890', 
    status: 'in progress', 
    time: 'Now'
  },
  { 
    id: 4, 
    phoneNumber: '+1 (555) 234-5678', 
    status: 'failed', 
    time: 'Today, 11:15 AM'
  }
]

const filterOptions = ['All', 'Scheduled', 'In Progress', 'Completed', 'Failed']

export default function AutoCallingPage() {
  const [activeFilter, setActiveFilter] = useState('All')
  const [phoneNumber, setPhoneNumber] = useState('+1 (555) 123-4567')
  const [date, setDate] = useState('04/04/2025')
  const [time, setTime] = useState('09:00 AM')
  const [scheduleFollowUp, setScheduleFollowUp] = useState(false)

  const filteredCalls = activeFilter === 'All' 
    ? calls 
    : calls.filter(call => call.status.toLowerCase() === activeFilter.toLowerCase())

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh', bgcolor: '#0F172A', color: '#e5e7eb' }}>
      {/* Animated Background */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.3 }}
        transition={{ duration: 2 }}
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'radial-gradient(circle at 50% 50%, #22d3ee, transparent 70%)',
          zIndex: 0
        }}
      />
      
      {/* Sidebar Navigation */}
      <Box component="nav" sx={{
        width: 256,
        borderRight: '1px solid rgba(34, 211, 153, 0.2)',
        bgcolor: 'rgba(30, 41, 59, 0.3)',
        backdropFilter: 'blur(24px)',
        display: 'flex',
        flexDirection: 'column',
        position: 'relative',
        zIndex: 1
      }}>
        <Box sx={{ p: 3, borderBottom: '1px solid rgba(34, 211, 153, 0.2)' }}>
          <Typography variant="h4" fontWeight="bold" color="#22d3ee">
            VoiceAI
          </Typography>
          <Typography variant="body2" color="#e5e7eb" sx={{ opacity: 0.7 }}>
            4.5 Communication
          </Typography>
        </Box>
        <Box sx={{ flex: 1, p: 2 }}>
          <List>
            {navItems.map((item) => (
              <motion.div key={item.name} whileHover={{ scale: 1.02 }}>
                <ListItemButton
                  component={Link}
                  href={item.path}
                  sx={{
                    borderRadius: 2,
                    mb: 1,
                    color: '#e5e7eb',
                    '&:hover': { bgcolor: 'rgba(51, 65, 85, 0.3)' }
                  }}
                >
                  <ListItemIcon sx={{ minWidth: 40, color: '#22d3ee' }}>
                    <item.icon />
                  </ListItemIcon>
                  <ListItemText 
                    primary={item.name} 
                    primaryTypographyProps={{ variant: 'body2' }} 
                  />
                </ListItemButton>
              </motion.div>
            ))}
          </List>
        </Box>
      </Box>

      {/* Main Content Area */}
      <Box component="main" sx={{ 
        flex: 1, 
        position: 'relative', 
        p: 4, 
        overflow: 'auto',
        display: 'flex',
        flexDirection: 'column',
        gap: 4,
        zIndex: 1
      }}>
        {/* Header Section */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <Box sx={{ mb: 4 }}>
            <Typography variant="h2" sx={{
              mb: 1,
              color: '#e5e7eb',
              fontWeight: 'bold'
            }}>
              Auto Calling
            </Typography>
            <Typography variant="body1" color="#22d3ee" sx={{ 
              opacity: 0.8,
              fontSize: '1rem'
            }}>
              Schedule and manage your automated calls
            </Typography>
          </Box>
        </motion.div>

        {/* Schedule a Call Section */}
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Paper sx={{
            p: 3,
            mb: 4,
            border: '1px solid rgba(34, 211, 153, 0.2)',
            bgcolor: 'rgba(30, 41, 59, 0.3)',
            borderRadius: 2
          }}>
            <Typography variant="h6" color="#22d3ee" sx={{ mb: 3 }}>
              Schedule a Call
            </Typography>
            
            <Box sx={{ mb: 2 }}>
              <Typography variant="body2" color="#22d3ee" sx={{ opacity: 0.8, mb: 1 }}>
                Phone Number
              </Typography>
              <TextField
                fullWidth
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                sx={{
                  '& .MuiOutlinedInput-root': {
                    color: '#e5e7eb',
                    '& fieldset': {
                      borderColor: 'rgba(34, 211, 153, 0.2)',
                    },
                    '&:hover fieldset': {
                      borderColor: 'rgba(34, 211, 153, 0.4)',
                    },
                  },
                }}
              />
            </Box>
            
            <Box display="flex" gap={2} sx={{ mb: 2 }}>
              <Box flex={1}>
                <Typography variant="body2" color="#22d3ee" sx={{ opacity: 0.8, mb: 1 }}>
                  Date
                </Typography>
                <TextField
                  fullWidth
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  sx={{
                    '& .MuiOutlinedInput-root': {
                      color: '#e5e7eb',
                      '& fieldset': {
                        borderColor: 'rgba(34, 211, 153, 0.2)',
                      },
                    },
                  }}
                />
              </Box>
              <Box flex={1}>
                <Typography variant="body2" color="#22d3ee" sx={{ opacity: 0.8, mb: 1 }}>
                  Time
                </Typography>
                <TextField
                  fullWidth
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  sx={{
                    '& .MuiOutlinedInput-root': {
                      color: '#e5e7eb',
                      '& fieldset': {
                        borderColor: 'rgba(34, 211, 153, 0.2)',
                      },
                    },
                  }}
                />
              </Box>
            </Box>
            
            <Box display="flex" alignItems="center" sx={{ mb: 3 }}>
              <input 
                type="checkbox" 
                checked={scheduleFollowUp}
                onChange={(e) => setScheduleFollowUp(e.target.checked)}
                style={{ marginRight: 8, accentColor: '#22d3ee' }}
              />
              <Typography variant="body2" color="#e5e7eb">
                Schedule follow-up call
              </Typography>
            </Box>
            
            <Box display="flex" gap={2}>
              <Button
                variant="outlined"
                sx={{
                  color: '#e5e7eb',
                  borderColor: 'rgba(34, 211, 153, 0.4)',
                  '&:hover': {
                    borderColor: 'rgba(34, 211, 153, 0.8)',
                  }
                }}
              >
                Reset
              </Button>
              <Button
                variant="contained"
                sx={{
                  background: 'linear-gradient(90deg, #34D399 0%, #10B981 100%)',
                  color: '#0F172A',
                  '&:hover': {
                    opacity: 0.9
                  }
                }}
                startIcon={<IoMdAdd />}
              >
                Schedule
              </Button>
            </Box>
          </Paper>
        </motion.div>

        {/* Stats and Import Section */}
        <Box display="flex" gap={4} sx={{ mb: 4 }}>
          {/* Call Records */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            style={{ flex: 3 }}
          >
            <Paper sx={{
              p: 3,
              border: '1px solid rgba(34, 211, 153, 0.2)',
              bgcolor: 'rgba(30, 41, 59, 0.3)',
              borderRadius: 2
            }}>
              <Typography variant="h6" color="#22d3ee" sx={{ mb: 3 }}>
                Call Records
              </Typography>
              
              <Box display="flex" gap={2}>
                <StatCard title="Total Calls" value="4" />
                <StatCard title="Scheduled" value="1" />
                <StatCard title="Completed" value="1" />
                <StatCard title="Failed" value="1" />
              </Box>
              
              <Button
                variant="outlined"
                startIcon={<FiDownload />}
                sx={{
                  mt: 3,
                  color: '#e5e7eb',
                  borderColor: 'rgba(34, 211, 153, 0.4)',
                  '&:hover': {
                    borderColor: 'rgba(34, 211, 153, 0.8)',
                  }
                }}
              >
                Download Call History
              </Button>
            </Paper>
          </motion.div>
          
          {/* Import Contacts */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            style={{ flex: 2 }}
          >
            <Paper sx={{
              p: 3,
              border: '1px solid rgba(34, 211, 153, 0.2)',
              bgcolor: 'rgba(30, 41, 59, 0.3)',
              borderRadius: 2,
              height: '100%',
              display: 'flex',
              flexDirection: 'column'
            }}>
              <Typography variant="h6" color="#22d3ee" sx={{ mb: 3 }}>
                Import Contacts
              </Typography>
              
              <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                <Box sx={{ textAlign: 'center', mb: 2 }}>
                  <FiUpload size={48} color="#22d3ee" style={{ opacity: 0.7 }} />
                </Box>
                <Typography variant="body2" color="#e5e7eb" sx={{ textAlign: 'center', mb: 3 }}>
                  Upload CSV or Excel file
                </Typography>
                
                <Button
                  variant="outlined"
                  component="label"
                  sx={{
                    color: '#e5e7eb',
                    borderColor: 'rgba(34, 211, 153, 0.4)',
                    '&:hover': {
                      borderColor: 'rgba(34, 211, 153, 0.8)',
                    }
                  }}
                >
                  Select File
                  <input type="file" hidden />
                </Button>
              </Box>
            </Paper>
          </motion.div>
        </Box>

        {/* Call List Section */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Paper sx={{
            p: 3,
            border: '1px solid rgba(34, 211, 153, 0.2)',
            bgcolor: 'rgba(30, 41, 59, 0.3)',
            borderRadius: 2
          }}>
            <Box display="flex" justifyContent="space-between" alignItems="center" sx={{ mb: 3 }}>
              <Typography variant="h6" color="#22d3ee">
                Call List
              </Typography>
              
              <Box display="flex" gap={1}>
                {filterOptions.map((filter) => (
                  <Chip
                    key={filter}
                    label={filter}
                    onClick={() => setActiveFilter(filter)}
                    sx={{
                      bgcolor: activeFilter === filter ? 'rgba(34, 211, 153, 0.2)' : 'transparent',
                      color: activeFilter === filter ? '#22d3ee' : '#e5e7eb',
                      border: activeFilter === filter ? 'none' : '1px solid rgba(34, 211, 153, 0.2)',
                      cursor: 'pointer'
                    }}
                  />
                ))}
              </Box>
            </Box>
            
            {filteredCalls.map((call) => (
              <CallCard key={call.id} call={call} />
            ))}
          </Paper>
        </motion.div>
      </Box>
    </Box>
  )
}