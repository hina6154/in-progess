'use client'

import { motion } from 'framer-motion'
import { 
  Box, 
  Typography, 
  Paper, 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableRow, 
  Button, 
  Chip,
  Divider,
  List,
  ListItem,
  ListItemText,
  ListItemButton,
  ListItemIcon
} from '@mui/material'
import { 
  FiHome, 
  FiPhone, 
  FiUsers, 
  FiDollarSign, 
  FiSettings,
  FiMail,
  FiCheck,
  FiClock
} from 'react-icons/fi'
import { FaRobot } from 'react-icons/fa'

export default function BillingPage() {
  return (
    <Box sx={{ 
      display: 'flex', 
      minHeight: '100vh', 
      bgcolor: '#0F172A',
      color: '#e5e7eb'
    }}>
      {/* Sidebar Navigation */}
      <Box
        component="nav"
        sx={{
          width: 280,
          height: '100vh',
          display: 'flex',
          flexDirection: 'column',
          borderRight: '1px solid rgba(51, 65, 85, 0.5)',
          bgcolor: 'rgba(30, 41, 59, 0.3)',
          backdropFilter: 'blur(24px)'
        }}
      >
        <Box sx={{ p: 3, borderBottom: '1px solid rgba(51, 65, 85, 0.5)' }}>
          <Typography variant="h4" sx={{ fontWeight: 'bold', color: '#34d399' }}>
            VoiceAI
          </Typography>
          <Typography variant="body2" sx={{ color: '#94a3b8', mt: 1 }}>
            3.1 Communications
          </Typography>
        </Box>
        <Box sx={{ flex: 1, p: 2 }}>
          <List>
            {[
              { name: 'Sales admin@voiceai', icon: FiMail },
              { name: 'Assistant', icon: FaRobot },
              { name: 'Active calling', icon: FiPhone },
              { name: 'Phone Numbers', icon: FiPhone },
              { name: 'Looks', icon: FiUsers },
              { name: 'Settings', icon: FiSettings }
            ].map((item, index) => (
              <ListItem key={index} disablePadding sx={{ mb: 1 }}>
                <ListItemButton sx={{
                  borderRadius: 2,
                  py: 1,
                  px: 2,
                  color: '#e5e7eb',
                  '&:hover': { bgcolor: 'rgba(51, 65, 85, 0.5)' }
                }}>
                  <ListItemIcon sx={{ minWidth: 40, color: '#94a3b8' }}>
                    <item.icon />
                  </ListItemIcon>
                  <ListItemText 
                    primary={item.name} 
                    primaryTypographyProps={{ variant: 'body2' }} 
                  />
                </ListItemButton>
              </ListItem>
            ))}
          </List>
        </Box>
      </Box>

      {/* Main Content */}
      <Box component="main" sx={{ 
        flex: 1, 
        position: 'relative', 
        overflow: 'auto',
        p: 4
      }}>
        {/* Billing Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Typography variant="h4" sx={{ 
            mb: 2, 
            color: '#34d399',
            fontWeight: 600
          }}>
            Billing
          </Typography>
          <Typography variant="body1" sx={{ 
            color: '#94a3b8', 
            mb: 4,
            maxWidth: '600px'
          }}>
            Manage your subscription and payment methods.
          </Typography>
        </motion.div>

        {/* Current Plan */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <Paper sx={{ 
            p: 3, 
            mb: 4,
            bgcolor: 'rgba(30, 41, 59, 0.3)',
            border: '1px solid rgba(51, 65, 85, 0.5)'
          }}>
            <Typography variant="h6" sx={{ 
              mb: 3, 
              color: '#34d399',
              fontWeight: 600
            }}>
              Current Plan
            </Typography>
            
            <Typography variant="h5" sx={{ 
              mb: 1, 
              color: '#e5e7eb',
              fontWeight: 600
            }}>
              Free Plan
            </Typography>
            <Typography variant="body2" sx={{ 
              color: '#94a3b8', 
              mb: 3
            }}>
              Limited Issuance for testing
            </Typography>

            <Table sx={{ mb: 2 }}>
              <TableHead>
                <TableRow>
                  <TableCell sx={{ color: '#94a3b8', borderBottom: 'none' }}></TableCell>
                  <TableCell sx={{ color: '#94a3b8', borderBottom: 'none' }}>Your Number</TableCell>
                  <TableCell sx={{ color: '#94a3b8', borderBottom: 'none' }}>Amounts</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                <TableRow>
                  <TableCell sx={{ color: '#e5e7eb', borderBottom: 'none' }}></TableCell>
                  <TableCell sx={{ color: '#e5e7eb', borderBottom: 'none' }}>127 / 120</TableCell>
                  <TableCell sx={{ color: '#e5e7eb', borderBottom: 'none' }}>1 / 1</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </Paper>
        </motion.div>

        <Divider sx={{ 
          bgcolor: '#334155', 
          mb: 4,
          opacity: 0.5
        }} />

        {/* Available Plans */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          <Typography variant="h6" sx={{ 
            mb: 3, 
            color: '#34d399',
            fontWeight: 600
          }}>
            Available Plans
          </Typography>

          <Box sx={{ 
            display: 'grid',
            gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: '1fr 1fr 1fr' },
            gap: 3,
            mb: 4
          }}>
            {[
              { name: 'Starter', price: '$29/mo', numbers: '30/Year Number', calls: '100/Year Number' },
              { name: 'Professional', price: '$58/mo', numbers: '30/Year Number', calls: '200/Year Number' },
              { name: 'Enterprise', price: '$87/mo', numbers: '30/Year Number', calls: '200/Year Number' }
            ].map((plan, index) => (
              <Paper key={index} sx={{ 
                p: 3, 
                bgcolor: 'rgba(30, 41, 59, 0.3)',
                border: '1px solid rgba(51, 65, 85, 0.5)',
                '&:hover': { borderColor: 'rgba(52, 211, 153, 0.5)' }
              }}>
                <Typography variant="h6" sx={{ 
                  mb: 1, 
                  color: '#e5e7eb',
                  fontWeight: 600
                }}>
                  {plan.name}
                </Typography>
                <Typography variant="h5" sx={{ 
                  mb: 2, 
                  color: '#34d399',
                  fontWeight: 600
                }}>
                  {plan.price}
                </Typography>
                <Box sx={{ mb: 3 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                    <FiCheck style={{ color: '#34d399', marginRight: '8px' }} />
                    <Typography variant="body2" sx={{ color: '#e5e7eb' }}>
                      {plan.numbers}
                    </Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                    <FiCheck style={{ color: '#34d399', marginRight: '8px' }} />
                    <Typography variant="body2" sx={{ color: '#e5e7eb' }}>
                      {plan.calls}
                    </Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <FiCheck style={{ color: '#34d399', marginRight: '8px' }} />
                    <Typography variant="body2" sx={{ color: '#e5e7eb' }}>
                      Submission
                    </Typography>
                  </Box>
                </Box>
                <Button
                  fullWidth
                  variant="outlined"
                  sx={{
                    color: '#34d399',
                    borderColor: '#34d399',
                    '&:hover': { borderColor: '#34d39990' }
                  }}
                >
                  Select Plan
                </Button>
              </Paper>
            ))}
          </Box>
        </motion.div>

        <Divider sx={{ 
          bgcolor: '#334155', 
          mb: 4,
          opacity: 0.5
        }} />

        {/* Payment Method */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          <Typography variant="h6" sx={{ 
            mb: 3, 
            color: '#34d399',
            fontWeight: 600
          }}>
            Payment Method
          </Typography>

          <Paper sx={{ 
            p: 3, 
            mb: 4,
            bgcolor: 'rgba(30, 41, 59, 0.3)',
            border: '1px solid rgba(51, 65, 85, 0.5)'
          }}>
            <Typography variant="body1" sx={{ 
              mb: 2, 
              color: '#e5e7eb'
            }}>
              No payment method added
            </Typography>
            <Button
              variant="outlined"
              sx={{
                color: '#34d399',
                borderColor: '#34d399',
                '&:hover': { borderColor: '#34d39990' }
              }}
            >
              Add Payment Method
            </Button>
          </Paper>

          <Typography variant="body2" sx={{ 
            color: '#94a3b8', 
            mb: 4,
            fontStyle: 'italic'
          }}>
            We accept cash costs, funds, and bank transfer
          </Typography>
        </motion.div>

        <Divider sx={{ 
          bgcolor: '#334155', 
          mb: 4,
          opacity: 0.5
        }} />

        {/* Billing History */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          <Typography variant="h6" sx={{ 
            mb: 3, 
            color: '#34d399',
            fontWeight: 600
          }}>
            Billing History
          </Typography>

          <Paper sx={{ 
            p: 3, 
            mb: 4,
            bgcolor: 'rgba(30, 41, 59, 0.3)',
            border: '1px solid rgba(51, 65, 85, 0.5)'
          }}>
            <Typography variant="body1" sx={{ 
              color: '#e5e7eb'
            }}>
              No billing history available
            </Typography>
          </Paper>
        </motion.div>

        <Divider sx={{ 
          bgcolor: '#334155', 
          mb: 4,
          opacity: 0.5
        }} />

        {/* Add-ons */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
        >
          <Typography variant="h6" sx={{ 
            mb: 3, 
            color: '#34d399',
            fontWeight: 600
          }}>
            Add-ons
          </Typography>

          <Box sx={{ 
            display: 'grid',
            gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' },
            gap: 3,
            mb: 4
          }}>
            <Paper sx={{ 
              p: 3, 
              bgcolor: 'rgba(30, 41, 59, 0.3)',
              border: '1px solid rgba(51, 65, 85, 0.5)'
            }}>
              <Typography variant="h6" sx={{ 
                mb: 1, 
                color: '#e5e7eb',
                fontWeight: 600
              }}>
                Additional Members
              </Typography>
              <Typography variant="body1" sx={{ 
                mb: 2, 
                color: '#94a3b8'
              }}>
                $1 per vendor / month
              </Typography>
              <Button
                variant="outlined"
                sx={{
                  color: '#34d399',
                  borderColor: '#34d399',
                  '&:hover': { borderColor: '#34d39990' }
                }}
              >
                Add
              </Button>
            </Paper>

            <Paper sx={{ 
              p: 3, 
              bgcolor: 'rgba(30, 41, 59, 0.3)',
              border: '1px solid rgba(51, 65, 85, 0.5)'
            }}>
              <Typography variant="h6" sx={{ 
                mb: 1, 
                color: '#e5e7eb',
                fontWeight: 600
              }}>
                Value Minutes Pack
              </Typography>
              <Typography variant="body1" sx={{ 
                mb: 2, 
                color: '#94a3b8'
              }}>
                Total cost number
              </Typography>
              <Button
                variant="outlined"
                sx={{
                  color: '#34d399',
                  borderColor: '#34d399',
                  '&:hover': { borderColor: '#34d39990' }
                }}
              >
                Add
              </Button>
            </Paper>
          </Box>
        </motion.div>
      </Box>
    </Box>
  )
}