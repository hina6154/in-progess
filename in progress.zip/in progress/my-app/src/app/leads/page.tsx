'use client'

import { motion } from 'framer-motion'
import { 
  Box, 
  Typography, 
  Paper, 
  Button,
  Chip,
  TextField,
  Divider,
  IconButton
} from '@mui/material'
import { FiMenu, FiX, FiUpload, FiPlus, FiUsers, FiHome, FiPhone, FiDollarSign, FiSettings } from 'react-icons/fi'
import { FaRobot } from 'react-icons/fa'
import { useState, useEffect } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'

const navItems = [
  { name: 'Dashboard', icon: FiHome, path: '/' },
  { name: 'Assistants', icon: FaRobot, path: '/assistant' },
  { name: 'Phone-Number', icon: FiSettings, path: '/phone-number' },
  { name: 'Auto Calling', icon: FiPhone, path: '/auto-calling' },
  { name: 'Leads', icon: FiUsers, path: '/leads' },
  { name: 'Billing', icon: FiDollarSign, path: '/billing' },
  { name: 'Settings', icon: FiSettings, path: '/settings' },
 
]

export default function LeadsPage() {
  const pathname = usePathname()
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [isMobile, setIsMobile] = useState(false)

  // Check if mobile view
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768)
      if (window.innerWidth < 768) {
        setSidebarOpen(false)
      } else {
        setSidebarOpen(true)
      }
    }

    checkMobile()
    window.addEventListener('resize', checkMobile)
    return () => window.removeEventListener('resize', checkMobile)
  }, [])

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh', bgcolor: '#0f172a' }}>
      {/* Animated Grid Background */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.1 }}
        transition={{ duration: 2 }}
        style={{
          position: 'fixed',
          inset: 0,
          backgroundImage: `
            linear-gradient(to right, #334155 1px, transparent 1px),
            linear-gradient(to bottom, #334155 1px, transparent 1px)`,
          backgroundSize: '40px 40px',
          zIndex: 0
        }}
      >
        <motion.div
          animate={{ backgroundPosition: ['0% 0%', '100% 100%'] }}
          transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
          style={{
            position: 'absolute',
            inset: 0,
            backgroundImage: `
              linear-gradient(45deg, #33415555 1px, transparent 1px),
              linear-gradient(-45deg, #33415555 1px, transparent 1px)`,
            backgroundSize: '40px 40px'
          }}
        />
      </motion.div>

      {/* Mobile Menu Button */}
      {isMobile && (
        <IconButton
          sx={{
            position: 'fixed',
            top: 16,
            left: 16,
            zIndex: 1200,
            color: '#34d399',
            bgcolor: 'rgba(30, 41, 59, 0.7)',
            backdropFilter: 'blur(10px)'
          }}
          onClick={() => setSidebarOpen(!sidebarOpen)}
        >
          {sidebarOpen ? <FiX size={24} /> : <FiMenu size={24} />}
        </IconButton>
      )}

      {/* Sidebar Navigation */}
      <Box
        component="nav"
        sx={{
          width: { xs: '100%', md: 256 },
          height: '100vh',
          display: 'flex',
          flexDirection: 'column',
          borderRight: '1px solid rgba(51, 65, 85, 0.5)',
          bgcolor: 'rgba(30, 41, 59, 0.3)',
          backdropFilter: 'blur(24px)',
          position: { xs: 'fixed', md: 'relative' },
          zIndex: 1100,
          transform: { 
            xs: sidebarOpen ? 'translateX(0)' : 'translateX(-100%)',
            md: 'translateX(0)'
          },
          transition: 'transform 0.3s ease-in-out'
        }}
      >
        <Box sx={{ p: 3, borderBottom: '1px solid rgba(51, 65, 85, 0.5)' }}>
          <Typography variant="h4" sx={{ fontWeight: 'bold', color: '#34d399' }}>
            Local Automation
          </Typography>
        </Box>
        <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 1, p: 2 }}>
          {navItems.map((item) => {
            const isActive = pathname === item.path
            const Icon = item.icon
            return (
              <Link href={item.path} key={item.name} style={{ textDecoration: 'none' }}>
                <motion.div 
                  whileHover={{ scale: 1.05 }} 
                  whileTap={{ scale: 0.95 }}
                  onClick={() => isMobile && setSidebarOpen(false)}
                >
                  <Box
                    sx={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 2,
                      borderRadius: 2,
                      p: 2,
                      bgcolor: isActive ? 'rgba(52, 211, 153, 0.1)' : 'transparent',
                      color: isActive ? '#34d399' : '#cbd5e1',
                      '&:hover': { bgcolor: 'rgba(51, 65, 85, 0.5)' }
                    }}
                  >
                    <Icon />
                    <Typography variant="body2" sx={{ fontWeight: 500 }}>
                      {item.name}
                    </Typography>
                  </Box>
                </motion.div>
              </Link>
            )
          })}
        </Box>
      </Box>

      {/* Main Content */}
      <Box 
        component="main" 
        sx={{ 
          flex: 1, 
          position: 'relative', 
          overflow: 'auto',
          ml: { xs: 0, md: sidebarOpen ? '256px' : 0 },
          transition: 'margin-left 0.3s ease-in-out',
          p: 4,
          zIndex: 1
        }}
      >
        {/* Header Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <Typography variant="h4" sx={{ 
            fontWeight: 'bold', 
            color: '#e5e7eb',
            mb: 1
          }}>
            Lead Automation
          </Typography>
          <Typography variant="body1" sx={{ 
            color: '#94a3b8',
            mb: 4
          }}>
            Manage and automate your lead generation
          </Typography>
        </motion.div>

        {/* Content Grid */}
        <Box sx={{ 
          display: 'grid',
          gridTemplateColumns: { xs: '1fr', md: '2fr 1fr' },
          gap: 4,
          mb: 4
        }}>
          {/* Main Content */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Paper sx={{ 
              p: 3,
              height: '100%',
              border: '1px solid rgba(51, 65, 85, 0.5)',
              bgcolor: 'rgba(30, 41, 59, 0.3)',
              backdropFilter: 'blur(24px)',
              borderRadius: 2,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              textAlign: 'center'
            }}>
              <FiUsers size={48} color="#94a3b8" style={{ opacity: 0.5, marginBottom: 16 }} />
              <Typography variant="h6" sx={{ color: '#e5e7eb', mb: 1 }}>
                No Leads Added Yet
              </Typography>
              <Typography variant="body2" sx={{ color: '#94a3b8', mb: 3 }}>
                Import leads or create them manually to get started
              </Typography>
              <Button
                variant="contained"
                startIcon={<FiPlus />}
                sx={{
                  background: 'linear-gradient(90deg, #34D399 0%, #10B981 100%)',
                  color: '#0F172A',
                  '&:hover': {
                    opacity: 0.9
                  }
                }}
              >
                Add First Lead
              </Button>
            </Paper>
          </motion.div>

          {/* Stats Sidebar */}
          <Box sx={{ 
            display: 'flex',
            flexDirection: 'column',
            gap: 3
          }}>
            {/* Lead Statistics */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              <Paper sx={{ 
                p: 3,
                border: '1px solid rgba(51, 65, 85, 0.5)',
                bgcolor: 'rgba(30, 41, 59, 0.3)',
                backdropFilter: 'blur(24px)',
                borderRadius: 2
              }}>
                <Typography variant="h6" sx={{ color: '#e5e7eb', mb: 2 }}>
                  Lead Statistics
                </Typography>
                <Box sx={{ display: 'grid', gap: 2 }}>
                  {[
                    { label: 'Total Leads', value: '0' },
                    { label: 'Called Today', value: '0' },
                    { label: 'Conversion Rate', value: '0%' }
                  ].map((stat, index) => (
                    <Box key={stat.label} sx={{ 
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      py: 1,
                      borderBottom: index < 2 ? '1px solid rgba(51, 65, 85, 0.3)' : 'none'
                    }}>
                      <Typography variant="body2" sx={{ color: '#94a3b8' }}>
                        {stat.label}
                      </Typography>
                      <Typography variant="body1" sx={{ color: '#e5e7eb', fontWeight: 'medium' }}>
                        {stat.value}
                      </Typography>
                    </Box>
                  ))}
                </Box>
              </Paper>
            </motion.div>

            {/* Quick Actions */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              <Paper sx={{ 
                p: 3,
                border: '1px solid rgba(51, 65, 85, 0.5)',
                bgcolor: 'rgba(30, 41, 59, 0.3)',
                backdropFilter: 'blur(24px)',
                borderRadius: 2
              }}>
                <Typography variant="h6" sx={{ color: '#e5e7eb', mb: 2 }}>
                  Quick Actions
                </Typography>
                <Box sx={{ display: 'grid', gap: 2 }}>
                  <Button
                    variant="outlined"
                    fullWidth
                    startIcon={<FiUpload />}
                    sx={{
                      color: '#e5e7eb',
                      borderColor: 'rgba(51, 65, 85, 0.5)',
                      '&:hover': {
                        borderColor: 'rgba(52, 211, 153, 0.5)'
                      }
                    }}
                  >
                    Import CSV
                  </Button>
                  <Button
                    variant="outlined"
                    fullWidth
                    startIcon={<FiUpload />}
                    sx={{
                      color: '#e5e7eb',
                      borderColor: 'rgba(51, 65, 85, 0.5)',
                      '&:hover': {
                        borderColor: 'rgba(52, 211, 153, 0.5)'
                      }
                    }}
                  >
                    Export Leads
                  </Button>
                </Box>
              </Paper>
            </motion.div>
          </Box>
        </Box>

        {/* Add Instructions Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Paper sx={{ 
            p: 3,
            border: '1px solid rgba(51, 65, 85, 0.5)',
            bgcolor: 'rgba(30, 41, 59, 0.3)',
            backdropFilter: 'blur(24px)',
            borderRadius: 2
          }}>
            <Typography variant="h6" sx={{ color: '#e5e7eb', mb: 2 }}>
              Add Instructions
            </Typography>
            <Box sx={{ display: 'grid', gap: 2 }}>
              {[
                'Import Leads',
                'Legend Statistics',
                'Total Leads',
                'Called Today',
                'Conversion Rate'
              ].map((item, index) => (
                <Box key={item} sx={{ 
                  display: 'flex',
                  alignItems: 'center',
                  gap: 2,
                  py: 1,
                  borderBottom: index < 4 ? '1px solid rgba(51, 65, 85, 0.3)' : 'none'
                }}>
                  <input 
                    type="checkbox" 
                    style={{ 
                      accentColor: '#34d399',
                      width: 16,
                      height: 16
                    }}
                  />
                  <Typography variant="body2" sx={{ 
                    color: index === 0 ? '#34d399' : '#94a3b8',
                    fontWeight: index === 0 ? 'medium' : 'normal'
                  }}>
                    {item}
                  </Typography>
                </Box>
              ))}
            </Box>
          </Paper>
        </motion.div>

        {/* Scanning Line Effect */}
        <motion.div
          initial={{ y: -100 }}
          animate={{ y: '100vh' }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: 'linear'
          }}
          style={{
            position: 'absolute',
            left: 0,
            right: 0,
            height: '1px',
            background: 'linear-gradient(to right, transparent, #34d399, transparent)',
            boxShadow: '0 0 30px rgba(52, 211, 153, 0.15)',
            zIndex: 0
          }}
        />
      </Box>
    </Box>
  )
}