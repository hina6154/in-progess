// app/dashboard/page.tsx
'use client'

import { motion } from 'framer-motion'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { FiHome, FiPhone, FiUsers, FiDollarSign, FiSettings } from 'react-icons/fi'
import { FaRobot } from 'react-icons/fa'

const navItems = [
  { name: 'Dashboard', icon: FiHome, path: '/' },
  { name: 'Assistants', icon: FaRobot, path: '/assistant' },
  { name: 'Auto Calling', icon: FiPhone, path: '/auto-calling' },
  { name: 'Leads', icon: FiUsers, path: '/leads' },
  { name: 'Billing', icon: FiDollarSign, path: '/billing' },
  { name: 'Settings', icon: FiSettings, path: '/settings' },
]

export default function DashboardPage() {
  const pathname = usePathname()

  return (
    <div className="flex min-h-screen bg-slate-900">
      {/* Sidebar with Cyan Accent */}
      <nav className="flex h-screen w-64 flex-col border-r border-cyan-500/20 bg-slate-800/30 backdrop-blur-lg">
        <div className="p-6">
          <h1 className="text-2xl font-bold text-cyan-400">VAPI</h1>
        </div>
        <div className="flex flex-1 flex-col space-y-2 p-4">
          {navItems.map((item) => {
            const isActive = pathname === item.path
            const Icon = item.icon
            return (
              <Link href={item.path} key={item.name}>
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className={`flex items-center space-x-4 rounded-lg p-4 transition-colors ${
                    isActive
                      ? 'bg-cyan-400/10 text-cyan-400'
                      : 'text-slate-300 hover:bg-slate-700/50'
                  }`}
                >
                  <Icon className="h-5 w-5" />
                  <span className="text-sm font-medium">{item.name}</span>
                </motion.div>
              </Link>
            )
          })}
        </div>
      </nav>

      {/* Main Content with Cyan Grid */}
      <main className="flex-1">
        <div className="relative h-screen w-full overflow-y-auto">
          {/* Cyan Grid Background */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.1 }}
            transition={{ duration: 2 }}
            className="absolute inset-0"
            style={{
              backgroundImage: `
                linear-gradient(to right, #06b6d4 1px, transparent 1px),
                linear-gradient(to bottom, #06b6d4 1px, transparent 1px)
              `,
              backgroundSize: '40px 40px',
            }}
          >
            <motion.div
              animate={{
                backgroundPosition: ['0% 0%', '100% 100%'],
              }}
              transition={{
                duration: 20,
                repeat: Infinity,
                ease: 'linear',
              }}
              className="absolute inset-0"
              style={{
                backgroundImage: `
                  linear-gradient(45deg, #06b6d455 1px, transparent 1px),
                  linear-gradient(-45deg, #06b6d455 1px, transparent 1px)
                `,
                backgroundSize: '40px 40px',
              }}
            />
          </motion.div>

          {/* Animated Cyan Lines */}
          <motion.div
            animate={{
              backgroundPositionX: ['0%', '100%'],
            }}
            transition={{
              duration: 15,
              repeat: Infinity,
              ease: 'linear',
            }}
            className="absolute inset-0 opacity-10"
            style={{
              backgroundImage: 'linear-gradient(to right, #06b6d4 1px, transparent 1px)',
              backgroundSize: '40px 40px',
            }}
          />

          {/* Content Container */}
          <div className="relative z-10 flex h-full items-center justify-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center"
            >
              <div className="rounded-xl border border-cyan-500/20 bg-slate-800/30 p-8 backdrop-blur-lg">
                <h2 className="text-4xl font-bold text-cyan-400 mb-4">
                  System Ready
                </h2>
                <p className="text-slate-400 mb-6 max-w-md">
                  Initiate workflows using the navigation panel or launch your
                  first automated communication sequence.
                </p>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="rounded-lg bg-cyan-400/10 px-6 py-3 text-cyan-400 transition-colors hover:bg-cyan-400/20"
                >
                  Start Automation
                </motion.button>
              </div>
            </motion.div>
          </div>
        </div>
      </main>
    </div>
  )
}












