'use client';

import { motion } from 'framer-motion';
import { useState } from 'react';
import { FiUser, FiLock, FiArrowRight, FiTerminal } from 'react-icons/fi';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

const LiningBackground = () => {
  return (
    <div className="fixed inset-0 -z-50 bg-gradient-to-br from-gray-900 via-gray-950 to-gray-900">
      {/* Scanning Lines */}
      <motion.div
        className="absolute inset-0 bg-[length:100%_2px] opacity-20"
        animate={{ backgroundPosition: ['0% 0%', '100% 100%'] }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: 'linear'
        }}
        style={{
          backgroundImage: `
            repeating-linear-gradient(
              0deg,
              rgba(0, 240, 255, 0.1) 0px,
              rgba(0, 240, 255, 0.1) 1px,
              transparent 1px,
              transparent 4px
            )
          `
        }}
      />

      {/* Diagonal Lines Animation */}
      <motion.div
        className="absolute inset-0"
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.1 }}
        transition={{ duration: 2 }}
      >
        <div className="absolute inset-0 bg-[length:40px_40px]"
             style={{
               backgroundImage: `
                 linear-gradient(
                   45deg,
                   rgba(0, 240, 255, 0.05) 25%,
                   transparent 25%,
                   transparent 50%,
                   rgba(0, 240, 255, 0.05) 50%,
                   rgba(0, 240, 255, 0.05) 75%,
                   transparent 75%,
                   transparent
                 )`
             }}>
        </div>
      </motion.div>

      {/* Moving Grid Lines */}
      <motion.div
        className="absolute inset-0 bg-[length:40px_40px]"
        animate={{
          backgroundPosition: ['0% 0%', '100% 100%']
        }}
        transition={{
          duration: 40,
          repeat: Infinity,
          ease: 'linear'
        }}
        style={{
          backgroundImage: `
            linear-gradient(rgba(0, 240, 255, 0.05) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0, 240, 255, 0.05) 1px, transparent 1px)
          `
        }}
      />
    </div>
  );
};

const formVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      staggerChildren: 0.2,
      delayChildren: 0.3
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 10 },
  visible: { opacity: 1, y: 0 }
};

export default function CyberLogin() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      if (username === 'admin' && password === 'admin') {
        router.push('/dashboard');
      } else {
        setError('Invalid credentials');
      }
    } catch {
      setError('Connection error');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="relative min-h-screen overflow-hidden">
      <LiningBackground />

      {/* Navigation Bar */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-gray-900/80 backdrop-blur-md border-b border-cyan-400/20">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <FiTerminal className="text-cyan-400 text-xl" />
            <span className="text-cyan-400 font-bold text-lg">CyberAuth</span>
          </div>
          <div className="flex space-x-4">
            <Link
              href="/dashboard"
              className="px-4 py-2 rounded-lg bg-cyan-400/10 hover:bg-cyan-400/20 border border-cyan-400/20 text-cyan-400 transition-all flex items-center space-x-2"
            >
              <span>Dashboard</span>
              <FiArrowRight className="text-sm" />
            </Link>
          </div>
        </div>
      </nav>

      <main className="flex min-h-screen items-center justify-center p-4 pt-24">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md relative z-10"
        >
          <motion.div
            className="p-8 rounded-xl bg-gray-900/90 backdrop-blur-xl border border-cyan-400/20 shadow-2xl shadow-cyan-400/10"
            variants={formVariants}
            initial="hidden"
            animate="visible"
            whileHover={{ boxShadow: '0 0 30px rgba(0, 240, 255, 0.1)' }}
          >
            <motion.div className="text-center mb-8" variants={itemVariants}>
              <motion.h1
                className="text-3xl font-bold mb-2"
                style={{
                  background: 'linear-gradient(160deg, #00f0ff 30%, #00ff9d 70%)',
                  WebkitBackgroundClip: 'text',
                  backgroundClip: 'text',
                  color: 'transparent'
                }}
                animate={{ filter: 'hue-rotate(0deg)' }}
                transition={{
                  duration: 8,
                  repeat: Infinity,
                  ease: 'linear'
                }}
              >
                Secure Access
              </motion.h1>
              <p className="text-gray-400 text-sm">Authorization Portal</p>
            </motion.div>

            {error && (
              <motion.div
                className="mb-4 p-3 bg-cyan-900/20 border border-cyan-400/20 rounded-lg text-cyan-400 text-sm"
                variants={itemVariants}
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
              >
                ⚠ {error}
              </motion.div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              <motion.div className="space-y-2" variants={itemVariants}>
                <label className="block text-sm font-medium text-cyan-100">Username</label>
                <motion.div
                  className="relative"
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.99 }}
                >
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <FiUser className="text-cyan-400/80" />
                  </div>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="w-full pl-10 pr-3 py-3 bg-gray-800/50 border border-cyan-400/20 rounded-lg focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400/30 outline-none transition-all text-gray-100 placeholder-gray-500"
                    placeholder="Enter username"
                    required
                  />
                </motion.div>
              </motion.div>

              <motion.div className="space-y-2" variants={itemVariants}>
                <label className="block text-sm font-medium text-cyan-100">Password</label>
                <motion.div
                  className="relative"
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.99 }}
                >
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <FiLock className="text-cyan-400/80" />
                  </div>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-10 pr-3 py-3 bg-gray-800/50 border border-cyan-400/20 rounded-lg focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400/30 outline-none transition-all text-gray-100 placeholder-gray-500"
                    placeholder="Enter password"
                    required
                  />
                </motion.div>
              </motion.div>

              <motion.div variants={itemVariants}>
                <motion.button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3 px-4 rounded-lg font-medium text-gray-900 bg-gradient-to-r from-cyan-400 to-emerald-400 hover:from-cyan-400/90 hover:to-emerald-400/90 focus:outline-none focus:ring-2 focus:ring-cyan-400/30 transition-all relative overflow-hidden"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  {isLoading ? (
                    <div className="flex items-center justify-center">
                      <motion.div
                        className="w-5 h-5 border-2 border-gray-900 border-t-transparent rounded-full mr-2"
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                      />
                      Authenticating...
                    </div>
                  ) : (
                    <div className="flex items-center justify-center">
                      Continue <FiArrowRight className="ml-2" />
                    </div>
                  )}
                </motion.button>
              </motion.div>
            </form>
          </motion.div>
        </motion.div>
      </main>

      <motion.div
        className="fixed bottom-0 left-0 right-0 p-4 text-center text-xs text-cyan-400/50 font-medium"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
      >
        <p>Secure Connection • Encrypted Session • v2.4.1</p>
      </motion.div>
    </div>
  );
}
