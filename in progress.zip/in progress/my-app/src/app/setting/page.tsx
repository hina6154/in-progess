'use client'

import { motion, useMotionValue, useTransform } from 'framer-motion'
import { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { 
  Box, 
  Typography, 
  Paper, 
  Divider, 
  Button, 
  TextField, 
  Switch, 
  List, 
  ListItem, 
  ListItemText, 
  ListItemButton,
  ListItemIcon,
  IconButton,
  Avatar
} from '@mui/material'
import { 
  FiHome, 
  FiPhone, 
  FiUsers, 
  FiDollarSign, 
  FiSettings,
  FiMail,
  FiUser,
  FiMoon,
  FiSun,
  FiBell,
  FiLock,
  FiCreditCard,
  FiDownload,
  FiUpload,
  FiCode,
  FiGlobe,
  FiDatabase,
  FiRefreshCw,
  FiShield,
  FiInfo
} from 'react-icons/fi'

export default function SettingsPage() {
  const pathname = usePathname()
  const [activeTab, setActiveTab] = useState('appearance')
  const [darkMode, setDarkMode] = useState(true)
  const [notifications, setNotifications] = useState(true)
  const [debugMode, setDebugMode] = useState(false)
  const [analytics, setAnalytics] = useState(true)
  const [autoUpdates, setAutoUpdates] = useState(true)
  const [privacyMode, setPrivacyMode] = useState(false)
  const [callRecording, setCallRecording] = useState(true)

  // Animated background values
  const x = useMotionValue(0)
  const y = useMotionValue(0)
  const rotateX = useTransform(y, [0, 100], [5, -5])
  const rotateY = useTransform(x, [0, 100], [-5, 5])

  const handleMouseMove = (e: React.MouseEvent) => {
    const rect = e.currentTarget.getBoundingClientRect()
    x.set(e.clientX - rect.left)
    y.set(e.clientY - rect.top)
  }

  const sidebarItems = [
    { name: 'admin@voice.ai', icon: FiMail, path: '/profile' },
    { name: 'Assistant', icon: FiUser, path: '/assistant' },
    { name: 'Auto-calling', icon: FiPhone, path: '/auto-calling' },
    { name: 'Phone Numbers', icon: FiPhone, path: '/phone-numbers' },
    { name: 'Leads', icon: FiUsers, path: '/leads' },
    { name: 'Billing', icon: FiDollarSign, path: '/billing' },
    { name: 'Settings', icon: FiSettings, path: '/settings' }
  ]

  const settingsTabs = [
    { name: 'Appearance', icon: FiSun, key: 'appearance' },
    { name: 'Account', icon: FiUser, key: 'account' },
    { name: 'Notifications', icon: FiBell, key: 'notifications' },
    { name: 'Advanced', icon: FiCode, key: 'advanced' }
  ]

  return (
    <Box sx={{ 
      display: 'flex', 
      minHeight: '100vh', 
      bgcolor: '#0F172A',
      color: '#e5e7eb',
      position: 'relative',
      overflow: 'hidden'
    }}>
      {/* Animated Grid Background */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.1 }}
        transition={{ duration: 2 }}
        style={{
          position: 'fixed',
          inset: 0,
          backgroundImage: `
            linear-gradient(to right, #334155 1px, transparent 1px),
            linear-gradient(to bottom, #334155 1px, transparent 1px)`,
          backgroundSize: '40px 40px',
          rotateX,
          rotateY,
          transformPerspective: 1000,
          transformStyle: 'preserve-3d'
        }}
      >
        <motion.div
          animate={{ 
            backgroundPosition: ['0% 0%', '100% 100%'],
            rotate: [0, 360]
          }}
          transition={{ 
            duration: 20, 
            repeat: Infinity, 
            ease: 'linear',
            rotate: { duration: 60, repeat: Infinity, ease: 'linear' }
          }}
          style={{
            position: 'absolute',
            inset: 0,
            backgroundImage: `
              linear-gradient(45deg, #33415555 1px, transparent 1px),
              linear-gradient(-45deg, #33415555 1px, transparent 1px)`,
            backgroundSize: '40px 40px',
            transformPerspective: 1000,
            transformStyle: 'preserve-3d'
          }}
        />
      </motion.div>

      {/* Floating Particles */}
      {[...Array(20)].map((_, i) => (
        <motion.div
          key={i}
          initial={{
            x: Math.random() * 100,
            y: Math.random() * 100,
            opacity: 0
          }}
          animate={{
            x: [null, Math.random() * 100],
            y: [null, Math.random() * 100],
            opacity: [0, 0.5, 0],
            scale: [0.5, 1.5]
          }}
          transition={{
            duration: Math.random() * 10 + 10,
            repeat: Infinity,
            repeatType: 'reverse',
            ease: 'linear'
          }}
          style={{
            position: 'absolute',
            width: 2,
            height: 2,
            borderRadius: '50%',
            background: '#34d399',
            zIndex: 0
          }}
        />
      ))}

      {/* Sidebar Navigation */}
      <Box
        component="nav"
        sx={{
          width: 280,
          height: '100vh',
          display: 'flex',
          flexDirection: 'column',
          borderRight: '1px solid rgba(51, 65, 85, 0.5)',
          bgcolor: 'rgba(15, 23, 42, 0.8)',
          backdropFilter: 'blur(24px)',
          position: 'relative',
          zIndex: 1
        }}
      >
        <Box sx={{ p: 3, borderBottom: '1px solid rgba(51, 65, 85, 0.5)' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <Avatar sx={{ bgcolor: 'rgba(52, 211, 153, 0.1)', color: '#34d399' }}>
              <FiUser size={20} />
            </Avatar>
            <Box>
              <Typography variant="h6" sx={{ fontWeight: 'bold', color: '#e5e7eb' }}>
                VoiceAI
              </Typography>
              <Typography variant="body2" sx={{ color: '#94a3b8' }}>
                3.1 Communications
              </Typography>
            </Box>
          </Box>
        </Box>
        <Box sx={{ flex: 1, p: 2, overflowY: 'auto' }}>
          <List>
            {sidebarItems.map((item) => (
              <ListItem key={item.path} disablePadding sx={{ mb: 1 }}>
                <ListItemButton
                  component={Link}
                  href={item.path}
                  selected={pathname === item.path}
                  sx={{
                    borderRadius: 2,
                    py: 1.5,
                    px: 2,
                    color: pathname === item.path ? '#34d399' : '#e5e7eb',
                    bgcolor: pathname === item.path ? 'rgba(52, 211, 153, 0.1)' : 'transparent',
                    '&:hover': {
                      bgcolor: pathname === item.path ? 'rgba(52, 211, 153, 0.2)' : 'rgba(51, 65, 85, 0.5)'
                    }
                  }}
                >
                  <ListItemIcon sx={{ minWidth: 40, color: pathname === item.path ? '#34d399' : '#94a3b8' }}>
                    <item.icon />
                  </ListItemIcon>
                  <ListItemText 
                    primary={item.name} 
                    primaryTypographyProps={{ 
                      variant: 'body2',
                      fontWeight: pathname === item.path ? 600 : 400
                    }} 
                  />
                </ListItemButton>
              </ListItem>
            ))}
          </List>
        </Box>
      </Box>

      {/* Main Content */}
      <Box 
        component="main" 
        sx={{ 
          flex: 1, 
          position: 'relative', 
          overflow: 'auto',
          height: '100vh',
          p: 4
        }}
        onMouseMove={handleMouseMove}
      >
        {/* Settings Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          style={{ maxWidth: '1200px', margin: '0 auto' }}
        >
          <Typography variant="h4" sx={{ 
            mb: 1, 
            color: '#34d399',
            fontWeight: 700,
            background: 'linear-gradient(90deg, #34D399 0%, #10B981 100%)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent'
          }}>
            Settings
          </Typography>
          <Typography variant="body1" sx={{ 
            color: '#94a3b8', 
            mb: 4,
            fontSize: '1.1rem'
          }}>
            Configure your account and application preferences
          </Typography>

          <Box sx={{ 
            display: 'flex', 
            gap: 4,
            flexDirection: { xs: 'column', md: 'row' },
            maxWidth: '1200px'
          }}>
            {/* Settings Navigation */}
            <Box sx={{ 
              width: { xs: '100%', md: 240 }, 
              flexShrink: 0,
              position: { xs: 'static', md: 'sticky' },
              top: 20
            }}>
              <Paper sx={{ 
                p: 2, 
                bgcolor: 'rgba(30, 41, 59, 0.5)',
                border: '1px solid rgba(51, 65, 85, 0.5)',
                borderRadius: 2,
                backdropFilter: 'blur(10px)'
              }}>
                <List>
                  {settingsTabs.map((tab) => (
                    <ListItem key={tab.key} disablePadding sx={{ mb: 1 }}>
                      <ListItemButton
                        onClick={() => setActiveTab(tab.key)}
                        selected={activeTab === tab.key}
                        sx={{
                          borderRadius: 1,
                          py: 1.5,
                          px: 2,
                          color: activeTab === tab.key ? '#34d399' : '#e5e7eb',
                          bgcolor: activeTab === tab.key ? 'rgba(52, 211, 153, 0.1)' : 'transparent',
                          '&:hover': {
                            bgcolor: activeTab === tab.key ? 'rgba(52, 211, 153, 0.2)' : 'rgba(51, 65, 85, 0.5)'
                          }
                        }}
                      >
                        <ListItemIcon sx={{ minWidth: 40, color: activeTab === tab.key ? '#34d399' : '#94a3b8' }}>
                          <tab.icon />
                        </ListItemIcon>
                        <ListItemText 
                          primary={tab.name} 
                          primaryTypographyProps={{ 
                            variant: 'body2',
                            fontWeight: activeTab === tab.key ? 600 : 400
                          }} 
                        />
                      </ListItemButton>
                    </ListItem>
                  ))}
                </List>
              </Paper>
            </Box>

            {/* Settings Content */}
            <Box sx={{ flex: 1, minWidth: 0 }}>
              <Paper sx={{ 
                p: { xs: 3, md: 4 }, 
                bgcolor: 'rgba(30, 41, 59, 0.5)',
                border: '1px solid rgba(51, 65, 85, 0.5)',
                borderRadius: 2,
                backdropFilter: 'blur(10px)'
              }}>
                {activeTab === 'appearance' && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.3 }}
                  >
                    <Typography variant="h6" sx={{ 
                      mb: 4, 
                      color: '#34d399',
                      fontWeight: 600,
                      fontSize: '1.25rem'
                    }}>
                      Appearance
                    </Typography>
                    
                    <Box sx={{ mb: 4 }}>
                      <Typography variant="subtitle1" sx={{ 
                        mb: 2, 
                        color: '#e5e7eb',
                        fontWeight: 500
                      }}>
                        Theme Preferences
                      </Typography>
                      <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
                        <Button
                          onClick={() => setDarkMode(false)}
                          variant={!darkMode ? 'contained' : 'outlined'}
                          sx={{
                            bgcolor: !darkMode ? 'rgba(52, 211, 153, 0.2)' : 'transparent',
                            color: !darkMode ? '#34d399' : '#e5e7eb',
                            borderColor: 'rgba(51, 65, 85, 0.5)',
                            flex: 1,
                            minWidth: '120px',
                            '&:hover': {
                              borderColor: !darkMode ? '#34d399' : 'rgba(51, 65, 85, 0.8)'
                            }
                          }}
                          startIcon={<FiSun />}
                        >
                          Light Mode
                        </Button>
                        <Button
                          onClick={() => setDarkMode(true)}
                          variant={darkMode ? 'contained' : 'outlined'}
                          sx={{
                            bgcolor: darkMode ? 'rgba(52, 211, 153, 0.2)' : 'transparent',
                            color: darkMode ? '#34d399' : '#e5e7eb',
                            borderColor: 'rgba(51, 65, 85, 0.5)',
                            flex: 1,
                            minWidth: '120px',
                            '&:hover': {
                              borderColor: darkMode ? '#34d399' : 'rgba(51, 65, 85, 0.8)'
                            }
                          }}
                          startIcon={<FiMoon />}
                        >
                          Dark Mode
                        </Button>
                      </Box>
                    </Box>
                  </motion.div>
                )}

                {activeTab === 'account' && (
                  <AccountSettingsTab />
                )}

                {activeTab === 'notifications' && (
                  <NotificationsTab 
                    notifications={notifications} 
                    setNotifications={setNotifications} 
                  />
                )}

                {activeTab === 'advanced' && (
                  <AdvancedSettingsTab 
                    debugMode={debugMode}
                    setDebugMode={setDebugMode}
                    analytics={analytics}
                    setAnalytics={setAnalytics}
                    autoUpdates={autoUpdates}
                    setAutoUpdates={setAutoUpdates}
                    privacyMode={privacyMode}
                    setPrivacyMode={setPrivacyMode}
                    callRecording={callRecording}
                    setCallRecording={setCallRecording}
                  />
                )}
              </Paper>
            </Box>
          </Box>
        </motion.div>
      </Box>
    </Box>
  )
}

function AccountSettingsTab() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      <Typography variant="h6" sx={{ 
        mb: 4, 
        color: '#34d399',
        fontWeight: 600,
        fontSize: '1.25rem'
      }}>
        Account Settings
      </Typography>
      
      <Box sx={{ mb: 4 }}>
        <Typography variant="subtitle1" sx={{ 
          mb: 2, 
          color: '#e5e7eb',
          fontWeight: 500
        }}>
          Profile Information
        </Typography>
        
        <Box sx={{ display: 'flex', gap: 3, mb: 3, flexDirection: { xs: 'column', sm: 'row' } }}>
          <Box sx={{ flexShrink: 0 }}>
            <Avatar sx={{ 
              width: 80, 
              height: 80, 
              bgcolor: 'rgba(52, 211, 153, 0.1)', 
              color: '#34d399',
              fontSize: '2rem'
            }}>
              <FiUser size={36} />
            </Avatar>
          </Box>
          <Box sx={{ flex: 1, display: 'flex', gap: 2, flexWrap: 'wrap' }}>
            <Button
              variant="outlined"
              sx={{
                color: '#34d399',
                borderColor: 'rgba(51, 65, 85, 0.5)',
                '&:hover': { borderColor: '#34d399' }
              }}
            >
              Upload New
            </Button>
            <Button
              variant="outlined"
              sx={{
                color: '#f43f5e',
                borderColor: 'rgba(51, 65, 85, 0.5)',
                '&:hover': { borderColor: '#f43f5e' }
              }}
            >
              Remove
            </Button>
          </Box>
        </Box>
        
        <Box sx={{ mb: 3 }}>
          <TextField
            fullWidth
            label="Full Name"
            defaultValue="John Doe"
            sx={{
              '& .MuiInputBase-root': { color: '#e5e7eb' },
              '& .MuiOutlinedInput-root': {
                '& fieldset': { borderColor: 'rgba(51, 65, 85, 0.5)' },
                '&:hover fieldset': { borderColor: 'rgba(52, 211, 153, 0.5)' }
              },
              '& .MuiInputLabel-root': { color: '#94a3b8' }
            }}
          />
        </Box>
        
        <Box sx={{ mb: 3 }}>
          <TextField
            fullWidth
            label="Email"
            defaultValue="john@example.com"
            sx={{
              '& .MuiInputBase-root': { color: '#e5e7eb' },
              '& .MuiOutlinedInput-root': {
                '& fieldset': { borderColor: 'rgba(51, 65, 85, 0.5)' },
                '&:hover fieldset': { borderColor: 'rgba(52, 211, 153, 0.5)' }
              },
              '& .MuiInputLabel-root': { color: '#94a3b8' }
            }}
          />
        </Box>
      </Box>
      
      <Button
        variant="contained"
        sx={{
          bgcolor: 'rgba(52, 211, 153, 0.2)',
          color: '#34d399',
          px: 4,
          py: 1.5,
          '&:hover': { bgcolor: 'rgba(52, 211, 153, 0.3)' }
        }}
      >
        Save Changes
      </Button>
    </motion.div>
  )
}

function NotificationsTab({ notifications, setNotifications }: { notifications: boolean, setNotifications: (val: boolean) => void }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      <Typography variant="h6" sx={{ 
        mb: 4, 
        color: '#34d399',
        fontWeight: 600,
        fontSize: '1.25rem'
      }}>
        Notification Settings
      </Typography>
      
      <Box sx={{ mb: 4 }}>
        <Typography variant="subtitle1" sx={{ 
          mb: 3, 
          color: '#e5e7eb',
          fontWeight: 500
        }}>
          Notification Preferences
        </Typography>
        
        <Box sx={{ mb: 3 }}>
          <Box sx={{ 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'space-between',
            mb: 1
          }}>
            <Box>
              <Typography variant="body1" sx={{ color: '#e5e7eb' }}>
                Email Notifications
              </Typography>
              <Typography variant="body2" sx={{ color: '#94a3b8' }}>
                Receive important updates via email
              </Typography>
            </Box>
            <Switch
              checked={notifications}
              onChange={() => setNotifications(!notifications)}
              color="primary"
            />
          </Box>
        </Box>
        
        <Box sx={{ mb: 3 }}>
          <Box sx={{ 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'space-between',
            mb: 1
          }}>
            <Box>
              <Typography variant="body1" sx={{ color: '#e5e7eb' }}>
                Push Notifications
              </Typography>
              <Typography variant="body2" sx={{ color: '#94a3b8' }}>
                Get real-time alerts on your device
              </Typography>
            </Box>
            <Switch
              checked={notifications}
              onChange={() => setNotifications(!notifications)}
              color="primary"
            />
          </Box>
        </Box>
        
        <Box sx={{ mb: 3 }}>
          <Box sx={{ 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'space-between',
            mb: 1
          }}>
            <Box>
              <Typography variant="body1" sx={{ color: '#e5e7eb' }}>
                SMS Alerts
              </Typography>
              <Typography variant="body2" sx={{ color: '#94a3b8' }}>
                Receive text message notifications
              </Typography>
            </Box>
            <Switch
              checked={notifications}
              onChange={() => setNotifications(!notifications)}
              color="primary"
            />
          </Box>
        </Box>
      </Box>
    </motion.div>
  )
}

function AdvancedSettingsTab({
  debugMode,
  setDebugMode,
  analytics,
  setAnalytics,
  autoUpdates,
  setAutoUpdates,
  privacyMode,
  setPrivacyMode,
  callRecording,
  setCallRecording
}: {
  debugMode: boolean
  setDebugMode: (val: boolean) => void
  analytics: boolean
  setAnalytics: (val: boolean) => void
  autoUpdates: boolean
  setAutoUpdates: (val: boolean) => void
  privacyMode: boolean
  setPrivacyMode: (val: boolean) => void
  callRecording: boolean
  setCallRecording: (val: boolean) => void
}) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      <Typography variant="h6" sx={{ 
        mb: 4, 
        color: '#34d399',
        fontWeight: 600,
        fontSize: '1.25rem'
      }}>
        Advanced Settings
      </Typography>
      
      {/* System Settings */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="subtitle1" sx={{ 
          mb: 3, 
          color: '#e5e7eb',
          fontWeight: 500
        }}>
          System Settings
        </Typography>
        
        <Box sx={{ mb: 3 }}>
          <Box sx={{ 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'space-between',
            mb: 1
          }}>
            <Box>
              <Typography variant="body1" sx={{ color: '#e5e7eb' }}>
                Debug Mode
              </Typography>
              <Typography variant="body2" sx={{ color: '#94a3b8' }}>
                Enable detailed logging for troubleshooting
              </Typography>
            </Box>
            <Switch
              checked={debugMode}
              onChange={() => setDebugMode(!debugMode)}
              color="primary"
            />
          </Box>
        </Box>
        
        <Box sx={{ mb: 3 }}>
          <Box sx={{ 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'space-between',
            mb: 1
          }}>
            <Box>
              <Typography variant="body1" sx={{ color: '#e5e7eb' }}>
                Usage Analytics
              </Typography>
              <Typography variant="body2" sx={{ color: '#94a3b8' }}>
                Help improve VoiceAI by sharing usage data
              </Typography>
            </Box>
            <Switch
              checked={analytics}
              onChange={() => setAnalytics(!analytics)}
              color="primary"
            />
          </Box>
        </Box>
        
        <Box sx={{ mb: 3 }}>
          <Box sx={{ 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'space-between',
            mb: 1
          }}>
            <Box>
              <Typography variant="body1" sx={{ color: '#e5e7eb' }}>
                Automatic Updates
              </Typography>
              <Typography variant="body2" sx={{ color: '#94a3b8' }}>
                Keep your app up to date automatically
              </Typography>
            </Box>
            <Switch
              checked={autoUpdates}
              onChange={() => setAutoUpdates(!autoUpdates)}
              color="primary"
            />
          </Box>
        </Box>
      </Box>
      
      <Divider sx={{ 
        bgcolor: 'rgba(51, 65, 85, 0.5)', 
        mb: 4
      }} />
      
      {/* Developer Options */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="subtitle1" sx={{ 
          mb: 3, 
          color: '#e5e7eb',
          fontWeight: 500
        }}>
          Developer Options
        </Typography>
        
        <Box sx={{ mb: 3 }}>
          <Typography variant="body1" sx={{ 
            mb: 1, 
            color: '#e5e7eb'
          }}>
            API Access
          </Typography>
          <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
            <Button
              variant="outlined"
              sx={{
                color: '#34d399',
                borderColor: 'rgba(51, 65, 85, 0.5)',
                '&:hover': { borderColor: '#34d399' }
              }}
            >
              Generate API Key
            </Button>
            <Button
              variant="outlined"
              sx={{
                color: '#34d399',
                borderColor: 'rgba(51, 65, 85, 0.5)',
                '&:hover': { borderColor: '#34d399' }
              }}
            >
              View Documentation
            </Button>
          </Box>
        </Box>
        
        <Box sx={{ mb: 3 }}>
          <Typography variant="body1" sx={{ 
            mb: 1, 
            color: '#e5e7eb'
          }}>
            Webhook Notifications
          </Typography>
          <TextField
            fullWidth
            defaultValue="https://example.com/webhook"
            sx={{
              '& .MuiInputBase-root': { color: '#e5e7eb' },
              '& .MuiOutlinedInput-root': {
                '& fieldset': { borderColor: 'rgba(51, 65, 85, 0.5)' },
                '&:hover fieldset': { borderColor: 'rgba(52, 211, 153, 0.5)' }
              }
            }}
          />
        </Box>
      </Box>
      
      <Divider sx={{ 
        bgcolor: 'rgba(51, 65, 85, 0.5)', 
        mb: 4
      }} />
      
      {/* Import/Export */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="subtitle1" sx={{ 
          mb: 3, 
          color: '#e5e7eb',
          fontWeight: 500
        }}>
          Import/Export Settings
        </Typography>
        
        <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
          <Button
            variant="outlined"
            startIcon={<FiDownload />}
            sx={{
              color: '#34d399',
              borderColor: 'rgba(51, 65, 85, 0.5)',
              '&:hover': { borderColor: '#34d399' }
            }}
          >
            Export Settings
          </Button>
          <Button
            variant="outlined"
            startIcon={<FiUpload />}
            sx={{
              color: '#34d399',
              borderColor: 'rgba(51, 65, 85, 0.5)',
              '&:hover': { borderColor: '#34d399' }
            }}
          >
            Import Settings
          </Button>
        </Box>
      </Box>
      
      <Divider sx={{ 
        bgcolor: 'rgba(51, 65, 85, 0.5)', 
        mb: 4
      }} />
      
      {/* Privacy Settings */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="subtitle1" sx={{ 
          mb: 3, 
          color: '#e5e7eb',
          fontWeight: 500
        }}>
          Privacy Settings
        </Typography>
        
        <Box sx={{ mb: 3 }}>
          <Box sx={{ 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'space-between',
            mb: 1
          }}>
            <Box>
              <Typography variant="body1" sx={{ color: '#e5e7eb' }}>
                Data Collection
              </Typography>
              <Typography variant="body2" sx={{ color: '#94a3b8' }}>
                Allow anonymous usage data collection
              </Typography>
            </Box>
            <Switch
              checked={analytics}
              onChange={() => setAnalytics(!analytics)}
              color="primary"
            />
          </Box>
        </Box>
        
        <Box sx={{ mb: 3 }}>
          <Box sx={{ 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'space-between',
            mb: 1
          }}>
            <Box>
              <Typography variant="body1" sx={{ color: '#e5e7eb' }}>
                Call Recording
              </Typography>
              <Typography variant="body2" sx={{ color: '#94a3b8' }}>
                Store call recordings for quality assurance
              </Typography>
            </Box>
            <Switch
              checked={callRecording}
              onChange={() => setCallRecording(!callRecording)}
              color="primary"
            />
          </Box>
        </Box>
        
        <Box sx={{ mb: 3 }}>
          <Box sx={{ 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'space-between',
            mb: 1
          }}>
            <Box>
              <Typography variant="body1" sx={{ color: '#e5e7eb' }}>
                Enhanced Privacy Mode
              </Typography>
              <Typography variant="body2" sx={{ color: '#94a3b8' }}>
                Limit data sharing with third parties
              </Typography>
            </Box>
            <Switch
              checked={privacyMode}
              onChange={() => setPrivacyMode(!privacyMode)}
              color="primary"
            />
          </Box>
        </Box>
        
        <Typography variant="body2" sx={{ 
          color: '#94a3b8', 
          fontStyle: 'italic',
          mb: 4
        }}>
          By enabling data collection, you agree to our Terms of Service and Privacy Policy.
        </Typography>
      </Box>
      
      <Divider sx={{ 
        bgcolor: 'rgba(51, 65, 85, 0.5)', 
        mb: 4
      }} />
      
      {/* System Information */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="subtitle1" sx={{ 
          mb: 3, 
          color: '#e5e7eb',
          fontWeight: 500
        }}>
          System Information
        </Typography>
        
        <Box sx={{ 
          display: 'grid',
          gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' },
          gap: 2,
          mb: 2
        }}>
          <Typography variant="body2" sx={{ color: '#94a3b8' }}>
            Version: <span style={{ color: '#e5e7eb' }}>1.0.0-alpha</span>
          </Typography>
          <Typography variant="body2" sx={{ color: '#94a3b8' }}>
            Last Updated: <span style={{ color: '#e5e7eb' }}>May 15, 2023</span>
          </Typography>
          <Typography variant="body2" sx={{ color: '#94a3b8' }}>
            Environment: <span style={{ color: '#e5e7eb' }}>Production</span>
          </Typography>
        </Box>
        
        <Button
          variant="outlined"
          startIcon={<FiRefreshCw />}
          sx={{
            color: '#34d399',
            borderColor: 'rgba(51, 65, 85, 0.5)',
            '&:hover': { borderColor: '#34d399' }
          }}
        >
          Check for Updates
        </Button>
      </Box>
      
      <Button
        variant="contained"
        sx={{
          bgcolor: 'rgba(52, 211, 153, 0.2)',
          color: '#34d399',
          px: 4,
          py: 1.5,
          '&:hover': { bgcolor: 'rgba(52, 211, 153, 0.3)' }
        }}
      >
        Save Advanced Settings
      </Button>
    </motion.div>
  )
}