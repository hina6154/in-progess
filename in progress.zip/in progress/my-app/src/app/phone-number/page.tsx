'use client'

import { useState,useEffect } from 'react'
import { motion } from 'framer-motion'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { 
  Box, 
  Typography, 
  Checkbox, 
  List, 
  ListItem, 
  ListItemText, 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableRow, 
  Button, 
  Chip,
  Paper,
  Divider,
  IconButton,
  ListItemButton,
  ListItemIcon
} from '@mui/material'
import { 
  FiHome, 
  FiPhone, 
  FiUsers, 
  FiDollarSign, 
  FiSettings,
  FiMenu,
  FiX
} from 'react-icons/fi'
import { FaRobot } from 'react-icons/fa'

interface FeatureState {
  hbeam: boolean
  argMessaging: boolean
  callScreening: boolean
  voiceTranscription: boolean
  callRecording: boolean
}

const navItems = [
  { name: 'Dashboard', icon: FiHome, path: '/' },
  { name: 'Assistants', icon: FaRobot, path: '/assistants' },
  { name: 'Phone Numbers', icon: FiPhone, path: '/phone-numbers' },
  { name: 'Leads', icon: FiUsers, path: '/leads' },
  { name: 'Billing', icon: FiDollarSign, path: '/billing' },
  { name: 'Settings', icon: FiSettings, path: '/settings' },
]

export default function PhoneNumberManager() {
  const pathname = usePathname()
  const [selectedNumbers, setSelectedNumbers] = useState<string[]>([])
  const [features, setFeatures] = useState<FeatureState>({
    hbeam: false,
    argMessaging: true,
    callScreening: true,
    voiceTranscription: true,
    callRecording: true
  })
  const [mobileOpen, setMobileOpen] = useState(false)
  const [isMobile, setIsMobile] = useState(false)

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }
    checkMobile()
    window.addEventListener('resize', checkMobile)
    return () => window.removeEventListener('resize', checkMobile)
  }, [])

  const handleNumberSelect = (number: string) => {
    setSelectedNumbers(prev => 
      prev.includes(number) 
        ? prev.filter(n => n !== number) 
        : [...prev, number]
    )
  }

  const handleFeatureToggle = (feature: keyof FeatureState) => {
    setFeatures(prev => ({ ...prev, [feature]: !prev[feature] }))
  }

  return (
    <Box sx={{ 
      display: 'flex', 
      minHeight: '100vh', 
      bgcolor: '#0F172A',
      color: '#e5e7eb'
    }}>
      {/* Mobile Sidebar Toggle */}
      {isMobile && (
        <IconButton
          sx={{
            position: 'fixed',
            top: 16,
            left: 16,
            zIndex: 1200,
            color: '#34d399',
            bgcolor: 'rgba(30, 41, 59, 0.7)',
            backdropFilter: 'blur(10px)'
          }}
          onClick={() => setMobileOpen(!mobileOpen)}
        >
          {mobileOpen ? <FiX size={24} /> : <FiMenu size={24} />}
        </IconButton>
      )}

      {/* Sidebar Navigation */}
      <Box
        component="nav"
        sx={{
          width: { xs: '100%', md: 280 },
          height: { xs: 'auto', md: '100vh' },
          display: { xs: mobileOpen ? 'flex' : 'none', md: 'flex' },
          flexDirection: 'column',
          borderRight: '1px solid rgba(51, 65, 85, 0.5)',
          bgcolor: 'rgba(30, 41, 59, 0.9)',
          backdropFilter: 'blur(24px)',
          position: { xs: 'fixed', md: 'relative' },
          zIndex: 1100,
          top: 0,
          left: 0,
          overflowY: 'auto'
        }}
      >
        <Box sx={{ p: 3, borderBottom: '1px solid rgba(51, 65, 85, 0.5)' }}>
          <Typography variant="h4" sx={{ fontWeight: 'bold', color: '#34d399' }}>
            VAPI
          </Typography>
          <Typography variant="body2" sx={{ color: '#94a3b8', mt: 1 }}>
            4.5 Communication
          </Typography>
        </Box>
        <Box sx={{ flex: 1, p: 2 }}>
          <List>
            {navItems.map((item) => {
              const isActive = pathname === item.path
              const Icon = item.icon
              return (
                <ListItem key={item.name} disablePadding>
                  <ListItemButton
                    component={Link}
                    href={item.path}
                    selected={isActive}
                    onClick={() => isMobile && setMobileOpen(false)}
                    sx={{
                      borderRadius: 2,
                      mb: 1,
                      color: isActive ? '#34d399' : '#e5e7eb',
                      bgcolor: isActive ? 'rgba(52, 211, 153, 0.1)' : 'transparent',
                      '&:hover': {
                        bgcolor: isActive ? 'rgba(52, 211, 153, 0.2)' : 'rgba(51, 65, 85, 0.5)'
                      }
                    }}
                  >
                    <ListItemIcon sx={{ minWidth: 40, color: isActive ? '#34d399' : '#94a3b8' }}>
                      <Icon />
                    </ListItemIcon>
                    <ListItemText 
                      primary={item.name} 
                      primaryTypographyProps={{ 
                        variant: 'body2',
                        fontWeight: isActive ? 600 : 400
                      }} 
                    />
                  </ListItemButton>
                </ListItem>
              )
            })}
          </List>
        </Box>
      </Box>

      {/* Main Content */}
      <Box 
        component="main" 
        sx={{ 
          flex: 1, 
          position: 'relative', 
          overflow: 'auto',
          height: '100vh',
          ml: { xs: 0, md: '280px' },
          p: { xs: 2, md: 4 }
        }}
      >
        {/* AI Communication Section */}
        <Box sx={{ mb: 4 }}>
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <Paper sx={{ 
              p: 3, 
              bgcolor: 'rgba(30, 41, 59, 0.3)',
              backdropFilter: 'blur(10px)',
              border: '1px solid rgba(51, 65, 85, 0.5)'
            }}>
              <Typography variant="h5" sx={{ 
                mb: 2, 
                color: '#34d399',
                fontWeight: 600
              }}>
                AI Communication
              </Typography>
              
              <List>
                {[
                  'Face: admin@voice.ai', 
                  'Assistant', 
                  'Phone Numbers', 
                  'Leads', 
                  'Billing', 
                  'Settings'
                ].map((item, index) => (
                  <ListItem key={`${item}-${index}`} sx={{ py: 0.5 }}>
                    <Checkbox 
                      checked={item === 'Assistant' || item === 'Settings'}
                      sx={{ 
                        color: '#34d399', 
                        '&.Mui-checked': { color: '#34d399' },
                        py: 0
                      }}
                    />
                    <ListItemText 
                      primary={item} 
                      sx={{ 
                        color: '#e5e7eb',
                        '& .MuiTypography-root': { fontSize: '0.875rem' }
                      }} 
                    />
                  </ListItem>
                ))}
              </List>
            </Paper>
          </motion.div>
        </Box>

        {/* Phone Numbers Section */}
        <motion.div initial={{ y: 20 }} animate={{ y: 0 }}>
          <Paper sx={{ 
            p: 3, 
            bgcolor: 'rgba(30, 41, 59, 0.3)',
            backdropFilter: 'blur(10px)',
            border: '1px solid rgba(51, 65, 85, 0.5)'
          }}>
            <Typography variant="h5" sx={{ 
              mb: 2, 
              color: '#34d399',
              fontWeight: 600
            }}>
              Phone Numbers
            </Typography>
            
            <Typography variant="body2" sx={{ 
              color: '#94a3b8', 
              mb: 3,
              lineHeight: 1.5
            }}>
              Currently only available for US-based phone numbers. 
              International support coming soon.
            </Typography>

            {/* Free Numbers Table */}
            <Box sx={{ mb: 4, overflowX: 'auto' }}>
              <Table>
                <TableHead>
                  <TableRow>
                    {['Free Vap! Numbers', 'Twilip', 'Manage'].map((header, index) => (
                      <TableCell key={index} sx={{ 
                        color: '#34d399',
                        fontWeight: 600,
                        borderBottom: 'none'
                      }}>
                        {header}
                      </TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  <TableRow>
                    <TableCell sx={{ color: '#e5e7eb', borderBottom: 'none' }}>
                      Get a Free Vap! Number
                    </TableCell>
                    <TableCell sx={{ borderBottom: 'none' }}>
                      <Box sx={{ display: 'flex', gap: 2 }}>
                        {['Select Area Code', 'Enter area code'].map((text, idx) => (
                          <Chip 
                            key={idx}
                            label={text}
                            sx={{ 
                              bgcolor: '#1e293b', 
                              color: '#34d399',
                              borderRadius: 1
                            }}
                          />
                        ))}
                      </Box>
                    </TableCell>
                    <TableCell sx={{ borderBottom: 'none' }} />
                  </TableRow>
                </TableBody>
              </Table>
            </Box>

            {/* Popular Area Codes */}
            <Box sx={{ mb: 4 }}>
              <Typography variant="h6" sx={{ 
                color: '#34d399', 
                mb: 2,
                fontWeight: 600
              }}>
                Popular Area Codes
              </Typography>
              
              <Box sx={{ 
                display: 'grid',
                gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: '1fr 1fr 1fr' },
                gap: 2
              }}>
                {[
                  '212 New York, NY', 
                  '213 Los Angeles, CA', 
                  '312 Chicago, IL',
                  '415 San Francisco, CA', 
                  '305 Miami, FL', 
                  '702 Las Vegas, NV'
                ].map((code, index) => (
                  <motion.div key={index} whileHover={{ scale: 1.02 }}>
                    <Chip 
                      label={code} 
                      sx={{ 
                        bgcolor: '#1e293b', 
                        color: '#e5e7eb', 
                        width: '100%',
                        borderRadius: 1
                      }} 
                    />
                  </motion.div>
                ))}
              </Box>
            </Box>

            {/* Available Numbers */}
            <Box sx={{ mb: 4 }}>
              <Typography variant="h6" sx={{ 
                color: '#34d399', 
                mb: 2,
                fontWeight: 600
              }}>
                Available Numbers
              </Typography>
              
              <Box sx={{ 
                display: 'grid',
                gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' },
                gap: 2
              }}>
                {[
                  '+1 (415) 555-1003',
                  '+1 (415) 555-1002',
                  '+1 (415) 555-1004',
                  '+1 (415) 555-1006'
                ].map((number, index) => (
                  <motion.div key={index} whileHover={{ scale: 1.02 }}>
                    <Box sx={{ 
                      display: 'flex', 
                      justifyContent: 'space-between', 
                      alignItems: 'center',
                      bgcolor: '#1e293b',
                      p: 2,
                      borderRadius: 1
                    }}>
                      <Typography variant="body2" sx={{ color: '#e5e7eb' }}>
                        {number}
                      </Typography>
                      <Button 
                        variant="outlined" 
                        sx={{ 
                          color: '#34d399', 
                          borderColor: '#34d399',
                          '&:hover': { borderColor: '#34d39990' }
                        }}
                      >
                        + Add
                      </Button>
                    </Box>
                  </motion.div>
                ))}
              </Box>
            </Box>

            <Divider sx={{ 
              bgcolor: '#334155', 
              mb: 4,
              opacity: 0.5
            }} />

            {/* Your Numbers Section */}
            <Box sx={{ mb: 4 }}>
              <Typography variant="h6" sx={{ 
                color: '#34d399', 
                mb: 2,
                fontWeight: 600
              }}>
                Your Numbers
              </Typography>
              
              <Box sx={{ 
                display: 'grid',
                gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' },
                gap: 2
              }}>
                {[
                  '+1 (415) 555-9876', 
                  '+1 (212) 555-1234'
                ].map((number, index) => (
                  <motion.div key={index} whileHover={{ scale: 1.02 }}>
                    <Box sx={{ 
                      display: 'flex', 
                      alignItems: 'center',
                      bgcolor: '#1e293b',
                      p: 2,
                      borderRadius: 1
                    }}>
                      <Checkbox
                        checked={selectedNumbers.includes(number)}
                        onChange={() => handleNumberSelect(number)}
                        sx={{ 
                          color: '#34d399', 
                          '&.Mui-checked': { color: '#34d399' },
                          mr: 1
                        }}
                      />
                      <Typography variant="body2" sx={{ color: '#e5e7eb' }}>
                        {number}
                      </Typography>
                    </Box>
                  </motion.div>
                ))}
              </Box>
            </Box>

            {/* Number Features */}
            <Box>
              <Typography variant="h6" sx={{ 
                color: '#34d399', 
                mb: 2,
                fontWeight: 600
              }}>
                Number Features
              </Typography>
              
              <Box sx={{ 
                display: 'grid',
                gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: '1fr 1fr 1fr' },
                gap: 2
              }}>
                {[
                  { label: 'Hbeam/Outboard Calling', key: 'hbeam' },
                  { label: 'ARG Messaging', key: 'argMessaging' },
                  { label: 'Call Screening', key: 'callScreening' },
                  { label: 'Voice Transcription', key: 'voiceTranscription' },
                  { label: 'Call Recording', key: 'callRecording' }
                ].map((feature, index) => (
                  <Box 
                    key={index}
                    sx={{ 
                      display: 'flex', 
                      alignItems: 'center',
                      bgcolor: '#1e293b',
                      p: 1.5,
                      borderRadius: 1
                    }}
                  >
                    <Checkbox
                      checked={features[feature.key as keyof FeatureState]}
                      onChange={() => handleFeatureToggle(feature.key as keyof FeatureState)}
                      sx={{ 
                        color: '#34d399', 
                        '&.Mui-checked': { color: '#34d399' },
                        mr: 1
                      }}
                    />
                    <Typography variant="body2" sx={{ color: '#e5e7eb' }}>
                      {feature.label}
                    </Typography>
                  </Box>
                ))}
              </Box>
            </Box>
          </Paper>
        </motion.div>
      </Box>
    </Box>
  )
}