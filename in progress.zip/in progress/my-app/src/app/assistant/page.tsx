'use client'

import { motion, useMotionValue, useTransform } from 'framer-motion'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Box, Typography, Button, TextField, Paper, IconButton } from '@mui/material'
import { FiHome, FiPhone, FiUsers, FiDollarSign, FiSettings, FiMenu, FiX } from 'react-icons/fi'
import { FaRobot } from 'react-icons/fa'
import { useState, useEffect } from 'react'

const navItems = [
  { name: 'Dashboard', icon: FiHome, path: '/' },
  { name: 'Assistants', icon: FaRobot, path: '/assistant' },
  { name: 'Phone-Number', icon: FiSettings, path: '/phone-number' },
  { name: 'Auto Calling', icon: FiPhone, path: '/auto-calling' },
  { name: 'Leads', icon: FiUsers, path: '/leads' },
  { name: 'Billing', icon: FiDollarSign, path: '/billing' },
  { name: 'Settings', icon: FiSettings, path: '/settings' },
 
]

const templates = [
  { name: 'Customer Support', description: 'Handle customer inquiries and provide support' },
  { name: 'Lead Qualification', description: 'Qualify leads and determine their needs' },
  { name: 'Appointment Scheduling', description: 'Schedule appointments and manage calendars' },
  { name: 'Info Collector', description: 'Gather information from customers efficiently' },
  { name: 'Care Coordinator', description: 'Coordinate patient care and follow-ups' },
  { name: 'Feedback Gatherer', description: 'Collect feedback and customer satisfaction data' },
  { name: 'Custom Assistant', description: 'Create a custom assistant from scratch' },
]

const containerVariants = {
  hidden: { opacity: 0 },
  visible: { 
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2
    }
  }
}

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: { type: 'spring', stiffness: 120 }
  }
}

const cardHoverVariants = {
  hover: { 
    scale: 1.02,
    boxShadow: '0 0 15px rgba(52, 211, 153, 0.3)'
  }
}

export default function DashboardPage() {
  const pathname = usePathname()
  const [selectedTemplate, setSelectedTemplate] = useState('')
  const [firstMessage, setFirstMessage] = useState('Hello! I\'m your AI assistant. How can I help you today?')
  const [mobileOpen, setMobileOpen] = useState(false)
  const [isMobile, setIsMobile] = useState(false)

  // Check if mobile view
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }
    checkMobile()
    window.addEventListener('resize', checkMobile)
    return () => window.removeEventListener('resize', checkMobile)
  }, [])

  // Animated background lines
  const x = useMotionValue(0)
  const y = useMotionValue(0)
  const rotateX = useTransform(y, [0, 100], [15, -15])
  const rotateY = useTransform(x, [0, 100], [-15, 15])

  const handleMouseMove = (e: React.MouseEvent) => {
    const rect = e.currentTarget.getBoundingClientRect()
    x.set(e.clientX - rect.left)
    y.set(e.clientY - rect.top)
  }

  return (
    <Box sx={{ 
      display: 'flex', 
      minHeight: '100vh', 
      bgcolor: '#0f172a',
      position: 'relative',
      overflow: 'hidden'
    }}>
      {/* Mobile Sidebar Toggle */}
      {isMobile && (
        <IconButton
          sx={{
            position: 'fixed',
            top: 16,
            left: 16,
            zIndex: 1200,
            color: '#34d399',
            bgcolor: 'rgba(30, 41, 59, 0.7)',
            backdropFilter: 'blur(10px)'
          }}
          onClick={() => setMobileOpen(!mobileOpen)}
        >
          {mobileOpen ? <FiX size={24} /> : <FiMenu size={24} />}
        </IconButton>
      )}

      {/* Sidebar Navigation */}
      <Box
        component="nav"
        sx={{
          width: { xs: '100%', md: 256 },
          height: { xs: 'auto', md: '100vh' },
          display: { xs: mobileOpen ? 'flex' : 'none', md: 'flex' },
          flexDirection: 'column',
          borderRight: '1px solid rgba(51, 65, 85, 0.5)',
          bgcolor: 'rgba(30, 41, 59, 0.9)',
          backdropFilter: 'blur(24px)',
          position: { xs: 'fixed', md: 'relative' },
          zIndex: 1100,
          top: 0,
          left: 0,
          overflowY: 'auto'
        }}
      >
        <Box sx={{ p: 3, borderBottom: '1px solid rgba(51, 65, 85, 0.5)' }}>
          <Typography variant="h4" sx={{ fontWeight: 'bold', color: '#34d399' }}>
            VAPI
          </Typography>
        </Box>
        <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 1, p: 2 }}>
          {navItems.map((item) => {
            const isActive = pathname === item.path
            const Icon = item.icon
            return (
              <Link href={item.path} key={item.name} style={{ textDecoration: 'none' }}>
                <motion.div 
                  whileHover={{ scale: 1.05 }} 
                  whileTap={{ scale: 0.95 }}
                  onClick={() => isMobile && setMobileOpen(false)}
                >
                  <Box
                    sx={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 2,
                      borderRadius: 2,
                      p: 2,
                      bgcolor: isActive ? 'rgba(52, 211, 153, 0.1)' : 'transparent',
                      color: isActive ? '#34d399' : '#cbd5e1',
                      '&:hover': { bgcolor: 'rgba(51, 65, 85, 0.5)' }
                    }}
                  >
                    <Icon />
                    <Typography variant="body2" sx={{ fontWeight: 500 }}>
                      {item.name}
                    </Typography>
                  </Box>
                </motion.div>
              </Link>
            )
          })}
        </Box>
      </Box>

      {/* Main Content */}
      <Box 
        component="main" 
        sx={{ 
          flex: 1, 
          position: 'relative', 
          overflow: 'auto',
          height: '100vh',
          ml: { xs: 0, md: '256px' }
        }}
        onMouseMove={handleMouseMove}
      >
        {/* Animated Grid Background */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.1 }}
          transition={{ duration: 2 }}
          style={{
            position: 'fixed',
            inset: 0,
            backgroundImage: `
              linear-gradient(to right, #334155 1px, transparent 1px),
              linear-gradient(to bottom, #334155 1px, transparent 1px)`,
            backgroundSize: '40px 40px',
            rotateX,
            rotateY,
            transformPerspective: 1000,
            transformStyle: 'preserve-3d'
          }}
        >
          <motion.div
            animate={{ 
              backgroundPosition: ['0% 0%', '100% 100%'],
              rotate: [0, 360]
            }}
            transition={{ 
              duration: 20, 
              repeat: Infinity, 
              ease: 'linear',
              rotate: { duration: 60, repeat: Infinity, ease: 'linear' }
            }}
            style={{
              position: 'absolute',
              inset: 0,
              backgroundImage: `
                linear-gradient(45deg, #33415555 1px, transparent 1px),
                linear-gradient(-45deg, #33415555 1px, transparent 1px)`,
              backgroundSize: '40px 40px',
              transformPerspective: 1000,
              transformStyle: 'preserve-3d'
            }}
          />
        </motion.div>

        {/* Floating Particles */}
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            initial={{
              x: Math.random() * 100,
              y: Math.random() * 100,
              opacity: 0
            }}
            animate={{
              x: [null, Math.random() * 100],
              y: [null, Math.random() * 100],
              opacity: [0, 0.5, 0],
              scale: [0.5, 1.5]
            }}
            transition={{
              duration: Math.random() * 10 + 10,
              repeat: Infinity,
              repeatType: 'reverse',
              ease: 'linear'
            }}
            style={{
              position: 'absolute',
              width: 2,
              height: 2,
              borderRadius: '50%',
              background: '#34d399',
              zIndex: 0
            }}
          />
        ))}

        {/* Content Section */}
        <Box sx={{ 
          position: 'relative', 
          zIndex: 1, 
          p: { xs: 2, md: 4 },
          maxWidth: '100%',
          overflowX: 'hidden'
        }}>
          <motion.div 
            initial="hidden"
            animate="visible"
            variants={containerVariants}
          >
            {/* Template Selection */}
            <motion.div variants={itemVariants}>
              <Paper sx={{ 
                mb: 4, 
                p: 3, 
                bgcolor: 'rgba(30, 41, 59, 0.7)', 
                backdropFilter: 'blur(24px)',
                border: '1px solid rgba(51, 65, 85, 0.5)'
              }}>
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                >
                  <Typography variant="h5" sx={{ color: '#34d399', mb: 2 }}>
                    Select an Assistant Template
                  </Typography>
                  <Typography sx={{ color: '#94a3b8', mb: 3 }}>
                    Choose a template to get started quickly or create a custom assistant from scratch.
                  </Typography>
                </motion.div>

                <Box sx={{ 
                  display: 'grid',
                  gridTemplateColumns: { xs: '1fr', md: 'repeat(2, 1fr)', lg: 'repeat(3, 1fr)' },
                  gap: 3
                }}>
                  {templates.map((template) => (
                    <motion.div 
                      key={template.name}
                      variants={itemVariants}
                      whileHover="hover"
                    >
                      <Paper
                        component={motion.div}
                        variants={cardHoverVariants}
                        onClick={() => setSelectedTemplate(template.name)}
                        sx={{
                          p: 3,
                          cursor: 'pointer',
                          border: '1px solid',
                          borderColor: selectedTemplate === template.name ? '#34d399' : 'rgba(51, 65, 85, 0.5)',
                          bgcolor: 'rgba(30, 41, 59, 0.5)'
                        }}
                      >
                        <motion.div
                          animate={{ color: selectedTemplate === template.name ? '#34d399' : '#f8fafc' }}
                          transition={{ duration: 0.2 }}
                        >
                          <Typography variant="h6" sx={{ mb: 1 }}>
                            {template.name}
                          </Typography>
                          <Typography variant="body2" sx={{ color: '#94a3b8' }}>
                            {template.description}
                          </Typography>
                        </motion.div>
                      </Paper>
                    </motion.div>
                  ))}
                </Box>
              </Paper>
            </motion.div>

            {/* Configuration Section */}
            <motion.div variants={itemVariants}>
              <Box sx={{ 
                display: 'flex',
                flexDirection: { xs: 'column', md: 'row' },
                gap: 4,
                mb: 4
              }}>
                {/* First Message Prompt */}
                <Box sx={{ flex: 1 }}>
                  <Paper 
                    component={motion.div}
                    initial={{ scale: 0.98 }}
                    animate={{ scale: 1 }}
                    transition={{ duration: 0.5 }}
                    sx={{ 
                      p: 3, 
                      bgcolor: 'rgba(30, 41, 59, 0.7)',
                      backdropFilter: 'blur(24px)',
                      border: '1px solid rgba(51, 65, 85, 0.5)'
                    }}
                  >
                    <Typography variant="h6" sx={{ color: '#34d399', mb: 2 }}>
                      First Message Prompt
                    </Typography>
                    <motion.div whileFocus={{ scale: 1.005 }}>
                      <TextField
                        fullWidth
                        multiline
                        rows={4}
                        value={firstMessage}
                        onChange={(e) => setFirstMessage(e.target.value)}
                        sx={{
                          '& .MuiInputBase-root': { 
                            color: '#f8fafc',
                            '& fieldset': {
                              borderColor: 'rgba(51, 65, 85, 0.5)'
                            },
                            '&:hover fieldset': {
                              borderColor: 'rgba(52, 211, 153, 0.5)'
                            }
                          }
                        }}
                      />
                    </motion.div>
                  </Paper>
                </Box>

                {/* Assistant Preview */}
                <Box sx={{ flex: 1 }}>
                  <Paper 
                    component={motion.div}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.3 }}
                    sx={{ 
                      p: 3, 
                      bgcolor: 'rgba(30, 41, 59, 0.7)',
                      backdropFilter: 'blur(24px)',
                      border: '1px solid rgba(51, 65, 85, 0.5)'
                    }}
                  >
                    <Typography variant="h6" sx={{ color: '#34d399', mb: 2 }}>
                      Assistant Preview
                    </Typography>
                    <motion.div 
  animate={{ 
    borderColor: '#34d399',
    boxShadow: '0 0 10px rgba(52, 211, 153, 0.1)'
  }}
  transition={{ repeat: Infinity, duration: 2, repeatType: 'reverse' }}
  style={{ 
    padding: '16px', 
    borderRadius: '4px', 
    backgroundColor: 'rgba(17, 24, 39, 0.5)',
    fontFamily: 'monospace',
    color: '#f8fafc',
    border: '1px solid transparent'
  }}
>
  <Typography style={{ color: '#34d399' }}>Assistant:</Typography>
  <motion.div
    key={firstMessage}
    initial={{ opacity: 0 }}
    animate={{ opacity: 1 }}
  >
    <Typography>{firstMessage}</Typography>
  </motion.div>
  <Typography style={{ marginTop: '16px', color: '#34d399' }}>User:</Typography>
  <Typography>"I'd like to know more about your services."</Typography>
</motion.div>
                  </Paper>
                </Box>
              </Box>
            </motion.div>

            {/* Integration & Tips Section */}
            <motion.div variants={itemVariants}>
              <Paper 
                component={motion.div}
                whileHover={{ scale: 1.005 }}
                sx={{ 
                  p: 3, 
                  bgcolor: 'rgba(30, 41, 59, 0.7)',
                  backdropFilter: 'blur(24px)',
                  border: '1px solid rgba(51, 65, 85, 0.5)'
                }}
              >
                <Typography variant="h6" sx={{ color: '#34d399', mb: 2 }}>
                  Test Voice Integration
                </Typography>
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.4 }}
                >
                  <Box component="pre" sx={{ 
                    p: 2, 
                    borderRadius: 1, 
                    bgcolor: 'rgba(17, 24, 39, 0.5)',
                    color: '#f8fafc',
                    fontFamily: 'monospace',
                    overflowX: 'auto'
                  }}>
                    {`const assistantId = "asst_123abc";
const config = {
  containerId: "assistant-container",
  theme: "dark"
};

NeoVoice.init(assistantId, config);`}
                  </Box>
                </motion.div>

                <Typography variant="h6" sx={{ color: '#34d399', mt: 4, mb: 2 }}>
                  Tips
                </Typography>
                <Box component="ol" sx={{ pl: 3, color: '#94a3b8' }}>
                  {[
                    'Use natural language in your prompts for better results',
                    'Higher temperature settings create more varied responses',
                    'Test your assistant with different user scenarios'
                  ].map((tip, index) => (
                    <motion.li 
                      key={tip}
                      variants={itemVariants}
                      custom={index}
                      style={{ marginBottom: 8 }}
                    >
                      {tip}
                    </motion.li>
                  ))}
                </Box>
              </Paper>
            </motion.div>
          </motion.div>
        </Box>
      </Box>
    </Box>
  )
}

