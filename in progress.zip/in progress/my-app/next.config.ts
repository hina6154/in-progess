import type { NextConfig } from 'next'

const nextConfig: NextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  images: {
    domains: ['example.com'], // Add domains for external images
  },
  // Enable experimental features if needed
 
  // Environment variables
  env: {
    API_URL: process.env.API_URL,
  },
  // Webpack customizations
  webpack: (config, { isServer }) => {
    // Add custom webpack configurations here
    return config
  },
  // Rewrites/Redirects
  async redirects() {
    return [
      {
        source: '/old-path',
        destination: '/new-path',
        permanent: true,
      },
    ]
  },
  // Internationalization (i18n) configuration
  i18n: {
    locales: ['en', 'fr'],
    defaultLocale: 'en',
  },
}

export default nextConfig